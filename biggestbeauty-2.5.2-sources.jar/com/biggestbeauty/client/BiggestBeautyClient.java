package com.biggestbeauty.client;

import com.biggestbeauty.client.event.ChatEventHandler;
import com.biggestbeauty.client.event.CombatEventHandler;
import com.biggestbeauty.client.event.KeybindHandler;
import com.biggestbeauty.client.event.RenderHandler;
import com.biggestbeauty.client.event.TickHandler;
import com.biggestbeauty.client.event.WorldRenderHandler;
import com.biggestbeauty.client.module.ModuleManager;
import com.biggestbeauty.client.util.ClientConfig;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * The Biggest Beauty Client
 * A cosmetic / utility / HUD overlay client for Minecraft 1.8.9.
 *
 * This client intentionally does NOT include combat-cheat modules
 * (killaura, reach, auto-clicker, aimbot, x-ray, etc). Everything here
 * is client-side rendering / QoL that doesn't touch other players'
 * game state or give an unfair server-side advantage.
 */
@Mod(modid = BiggestBeautyClient.MODID, name = BiggestBeautyClient.NAME, version = BiggestBeautyClient.VERSION)
public class BiggestBeautyClient {

    public static final String MODID = "biggestbeauty";
    public static final String NAME = "The Biggest Beauty Client";
    public static final String VERSION = "2.5.2";

    @Mod.Instance(MODID)
    public static BiggestBeautyClient instance;

    public static ModuleManager moduleManager;
    public ClientConfig config;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        moduleManager = new ModuleManager();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new KeybindHandler());
        MinecraftForge.EVENT_BUS.register(new RenderHandler());
        MinecraftForge.EVENT_BUS.register(new CombatEventHandler());
        MinecraftForge.EVENT_BUS.register(new ChatEventHandler());
        MinecraftForge.EVENT_BUS.register(new TickHandler());
        MinecraftForge.EVENT_BUS.register(new WorldRenderHandler());
        MinecraftForge.EVENT_BUS.register(this);

        moduleManager.registerDefaults();

        config = ClientConfig.load();
        config.applyToModules();
        if (config.clientName != null && !config.clientName.trim().isEmpty()) {
            org.lwjgl.opengl.Display.setTitle(config.clientName);
        }
    }

    private int autosaveTicks = 0;

    @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        autosaveTicks++;
        if (autosaveTicks >= 20 * 30) {
            autosaveTicks = 0;
            if (config != null) config.save();
        }
    }
}
