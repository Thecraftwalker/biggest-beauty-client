package com.biggestbeauty.client.event;

import com.biggestbeauty.client.BiggestBeautyClient;
import com.biggestbeauty.client.module.impl.misc.ChatTimestampsModule;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ChatEventHandler {

    private final SimpleDateFormat format = new SimpleDateFormat("HH:mm");

    @SubscribeEvent
    public void onChat(ClientChatReceivedEvent event) {
        ChatTimestampsModule module = BiggestBeautyClient.moduleManager.getModule(ChatTimestampsModule.class);
        if (module == null || !module.isEnabled()) return;
        if (event.type != 0) return;

        ChatComponentText prefix = new ChatComponentText("[" + format.format(new Date()) + "] ");
        prefix.func_150256_b().func_150238_a(net.minecraft.util.EnumChatFormatting.GRAY);
        prefix.func_150257_a(event.message);
        event.message = prefix;
    }
}
