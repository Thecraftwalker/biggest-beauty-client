package com.biggestbeauty.client.event;

import com.biggestbeauty.client.BiggestBeautyClient;
import com.biggestbeauty.client.module.impl.cosmetic.DamageIndicatorModule;
import com.biggestbeauty.client.module.impl.cosmetic.HitParticlesModule;
import com.biggestbeauty.client.module.impl.cosmetic.KillEffectModule;
import com.biggestbeauty.client.module.impl.hud.ComboHud;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class CombatEventHandler {

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        Entity target = event.target;
        if (target == null) return;

        HitParticlesModule particles = BiggestBeautyClient.moduleManager.getModule(HitParticlesModule.class);
        if (particles != null && particles.isEnabled()) {
            particles.spawn(target);
        }

        ComboHud combo = BiggestBeautyClient.moduleManager.getModule(ComboHud.class);
        if (combo != null && combo.isEnabled()) {
            combo.onHit(target);
        }
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        EntityLivingBase deceased = event.entityLiving;
        if (deceased == null || deceased.field_70170_p == null || !deceased.field_70170_p.field_72995_K) return;

        if (deceased.func_110144_aD() == null) return;
        if (deceased.func_110144_aD() != net.minecraft.client.Minecraft.func_71410_x().field_71439_g) return;

        KillEffectModule killEffect = BiggestBeautyClient.moduleManager.getModule(KillEffectModule.class);
        if (killEffect != null && killEffect.isEnabled()) {
            killEffect.spawn(deceased);
        }
    }

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        if (event.source == null || event.source.func_76346_g() != net.minecraft.client.Minecraft.func_71410_x().field_71439_g) return;

        DamageIndicatorModule indicators = BiggestBeautyClient.moduleManager.getModule(DamageIndicatorModule.class);
        if (indicators != null && indicators.isEnabled()) {
            indicators.addIndicator(event.entityLiving.func_145782_y(), event.ammount);
        }
    }
}
