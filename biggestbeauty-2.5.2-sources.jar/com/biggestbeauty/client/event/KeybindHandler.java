package com.biggestbeauty.client.event;

import com.biggestbeauty.client.BiggestBeautyClient;
import com.biggestbeauty.client.gui.ClientGui;
import com.biggestbeauty.client.module.impl.misc.AntiAfkModule;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

public class KeybindHandler {

    public static final int GUI_KEYBIND = Keyboard.KEY_RSHIFT;

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        Minecraft mc = Minecraft.func_71410_x();

        AntiAfkModule antiAfk = BiggestBeautyClient.moduleManager.getModule(AntiAfkModule.class);
        if (antiAfk != null) antiAfk.onMouseOrKeyActivity();

        if (mc.field_71462_r != null) return;

        if (Keyboard.getEventKey() == GUI_KEYBIND && Keyboard.getEventKeyState()) {
            mc.func_147108_a(new ClientGui());
            return;
        }

        if (Keyboard.getEventKeyState()) {
            BiggestBeautyClient.moduleManager.handleKeybind(Keyboard.getEventKey());
        }
    }
}
