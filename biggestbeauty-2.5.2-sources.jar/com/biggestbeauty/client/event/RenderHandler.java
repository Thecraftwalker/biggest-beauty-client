package com.biggestbeauty.client.event;

import com.biggestbeauty.client.BiggestBeautyClient;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.module.Setting;
import com.biggestbeauty.client.module.impl.hud.CPSCounter;
import com.biggestbeauty.client.module.impl.hud.HungerWarningModule;
import com.biggestbeauty.client.module.impl.hud.LowHealthWarningModule;
import com.biggestbeauty.client.module.impl.misc.AntiAfkModule;
import com.biggestbeauty.client.module.impl.render.CustomCrosshairModule;
import com.biggestbeauty.client.module.impl.render.MotionBlurModule;
import com.biggestbeauty.client.module.impl.render.NoFireModule;
import com.biggestbeauty.client.module.impl.render.NoHelmetOverlayModule;
import com.biggestbeauty.client.module.impl.render.NoHurtCamModule;
import com.biggestbeauty.client.module.impl.render.NoPortalOverlayModule;
import com.biggestbeauty.client.module.impl.render.ZoomModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class RenderHandler {

    private int motionBlurTexture = -1;
    private int motionBlurWidth = -1;
    private int motionBlurHeight = -1;

    @SubscribeEvent
    public void onRenderOverlayPre(RenderGameOverlayEvent.Pre event) {
        if (event.type == RenderGameOverlayEvent.ElementType.CROSSHAIRS) {
            CustomCrosshairModule crosshair = BiggestBeautyClient.moduleManager.getModule(CustomCrosshairModule.class);
            if (crosshair != null && crosshair.isEnabled()) {
                event.setCanceled(true);
            }
            return;
        }

        if (event.type == RenderGameOverlayEvent.ElementType.HELMET) {
            NoHelmetOverlayModule noHelmet = BiggestBeautyClient.moduleManager.getModule(NoHelmetOverlayModule.class);
            if (noHelmet != null && noHelmet.isEnabled()) {
                event.setCanceled(true);
            }
            return;
        }

        if (event.type == RenderGameOverlayEvent.ElementType.PORTAL) {
            NoPortalOverlayModule noPortal = BiggestBeautyClient.moduleManager.getModule(NoPortalOverlayModule.class);
            if (noPortal != null && noPortal.isEnabled()) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public void onRenderOverlayPost(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;

        Minecraft mc = Minecraft.func_71410_x();
        ScaledResolution sr = new ScaledResolution(mc);

        drawMotionBlurGhost(mc, sr);

        for (HudModule module : BiggestBeautyClient.moduleManager.getHudModules()) {
            if (module.isEnabled()) {
                module.render(sr, false);
            }
        }

        CustomCrosshairModule crosshair = BiggestBeautyClient.moduleManager.getModule(CustomCrosshairModule.class);
        if (crosshair != null && crosshair.isEnabled()) {
            crosshair.render(sr);
        }

        LowHealthWarningModule lowHealth = BiggestBeautyClient.moduleManager.getModule(LowHealthWarningModule.class);
        if (lowHealth != null && lowHealth.isEnabled()) {
            lowHealth.render(sr);
        }

        HungerWarningModule hungerWarning = BiggestBeautyClient.moduleManager.getModule(HungerWarningModule.class);
        if (hungerWarning != null && hungerWarning.isEnabled()) {
            hungerWarning.render(sr);
        }

        renderToasts(sr);

        captureMotionBlurFrame(mc);
    }

    private void renderToasts(ScaledResolution sr) {
        int y = sr.func_78328_b() / 2 - 20;
        int x = sr.func_78326_a() - 6;
        for (com.biggestbeauty.client.util.ToastQueue.Toast toast : com.biggestbeauty.client.util.ToastQueue.getActive()) {
            String text = toast.message;
            int width = Minecraft.func_71410_x().field_71466_p.func_78256_a(text);
            com.biggestbeauty.client.util.RenderUtil.drawRect(x - width - 12, y - 3, x, y + 11, 0xA0141018);
            com.biggestbeauty.client.util.RenderUtil.drawStringRightAligned(text, x - 6, y, 0xFFFFFFFF);
            y += 16;
        }
    }

    private void drawMotionBlurGhost(Minecraft mc, ScaledResolution sr) {
        MotionBlurModule blur = BiggestBeautyClient.moduleManager.getModule(MotionBlurModule.class);
        if (blur == null || !blur.isEnabled()) {
            if (motionBlurTexture != -1) {
                GL11.glDeleteTextures(motionBlurTexture);
                motionBlurTexture = -1;
            }
            return;
        }
        if (motionBlurTexture == -1) return;

        try {
            Setting strength = blur.getSetting("Strength");
            float alpha = (strength != null ? strength.getSlider() : 35f) / 100f;

            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179120_a(770, 771, 1, 0);
            GlStateManager.func_179118_c();
            GlStateManager.func_179140_f();
            GlStateManager.func_179144_i(motionBlurTexture);
            GlStateManager.func_179131_c(1f, 1f, 1f, alpha);

            Tessellator tess = Tessellator.func_178181_a();
            WorldRenderer wr = tess.func_178180_c();
            int w = sr.func_78326_a();
            int h = sr.func_78328_b();
            wr.func_181668_a(GL11.GL_QUADS, DefaultVertexFormats.field_181707_g);
            wr.func_181662_b(0, h, 0).func_181673_a(0, 0).func_181675_d();
            wr.func_181662_b(w, h, 0).func_181673_a(1, 0).func_181675_d();
            wr.func_181662_b(w, 0, 0).func_181673_a(1, 1).func_181675_d();
            wr.func_181662_b(0, 0, 0).func_181673_a(0, 1).func_181675_d();
            tess.func_78381_a();

            GlStateManager.func_179131_c(1f, 1f, 1f, 1f);
            GlStateManager.func_179141_d();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        } catch (Exception e) {
            MotionBlurModule m = BiggestBeautyClient.moduleManager.getModule(MotionBlurModule.class);
            if (m != null) m.setEnabled(false);
            System.err.println("[BiggestBeauty] Motion Blur hit a rendering error and was disabled: " + e.getMessage());
        }
    }

    private void captureMotionBlurFrame(Minecraft mc) {
        MotionBlurModule blur = BiggestBeautyClient.moduleManager.getModule(MotionBlurModule.class);
        if (blur == null || !blur.isEnabled()) return;

        try {
            int width = mc.field_71443_c;
            int height = mc.field_71440_d;

            if (motionBlurTexture == -1) {
                motionBlurTexture = GL11.glGenTextures();
                motionBlurWidth = -1;
            }

            GlStateManager.func_179144_i(motionBlurTexture);
            if (width != motionBlurWidth || height != motionBlurHeight) {
                GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, width, height, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, (java.nio.ByteBuffer) null);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
                motionBlurWidth = width;
                motionBlurHeight = height;
            }
            GL11.glCopyTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, 0, 0, width, height, 0);
        } catch (Exception e) {
            blur.setEnabled(false);
            System.err.println("[BiggestBeauty] Motion Blur hit a capture error and was disabled: " + e.getMessage());
        }
    }

    @SubscribeEvent
    public void onMouseEvent(MouseEvent event) {
        int button = event.button;

        AntiAfkModule antiAfk = BiggestBeautyClient.moduleManager.getModule(AntiAfkModule.class);
        if (antiAfk != null) antiAfk.onMouseOrKeyActivity();

        if (button == -1 || !event.buttonstate) return;

        CPSCounter cps = BiggestBeautyClient.moduleManager.getModule(CPSCounter.class);
        if (cps == null) return;

        if (button == 0) cps.onLeftClick();
        if (button == 1) cps.onRightClick();
    }

    @SubscribeEvent
    public void onFovUpdate(FOVUpdateEvent event) {
        ZoomModule zoom = BiggestBeautyClient.moduleManager.getModule(ZoomModule.class);
        if (zoom != null && zoom.isZooming()) {
            event.newfov = zoom.apply(event.newfov);
        }
    }

    @SubscribeEvent
    public void onRenderBlockOverlay(RenderBlockOverlayEvent event) {
        if (event.overlayType != RenderBlockOverlayEvent.OverlayType.FIRE) return;
        NoFireModule noFire = BiggestBeautyClient.moduleManager.getModule(NoFireModule.class);
        if (noFire != null && noFire.isEnabled()) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onCameraSetup(EntityViewRenderEvent.CameraSetup event) {
        NoHurtCamModule noHurtCam = BiggestBeautyClient.moduleManager.getModule(NoHurtCamModule.class);
        if (noHurtCam == null || !noHurtCam.isEnabled()) return;

        Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71439_g != null && mc.field_71439_g.field_70737_aN > 0) {
            event.roll = 0f;
        }
    }
}
