package com.biggestbeauty.client.event;

import com.biggestbeauty.client.BiggestBeautyClient;
import com.biggestbeauty.client.module.impl.cosmetic.ArrowTrailModule;
import com.biggestbeauty.client.module.impl.cosmetic.LevelUpEffectModule;
import com.biggestbeauty.client.module.impl.cosmetic.ParticleTrailModule;
import com.biggestbeauty.client.module.impl.hud.PingGraphHud;
import com.biggestbeauty.client.module.impl.hud.VelocityHud;
import com.biggestbeauty.client.module.impl.misc.AntiAfkModule;
import com.biggestbeauty.client.module.impl.misc.AutoRespawnModule;
import com.biggestbeauty.client.module.impl.misc.AutoSprintModule;
import com.biggestbeauty.client.module.impl.performance.NetOptimizerModule;
import com.biggestbeauty.client.module.impl.render.FullbrightModule;
import com.biggestbeauty.client.module.impl.render.ZoomModule;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class TickHandler {

    private int fpsSampleCounter = 0;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71439_g == null) return;

        ZoomModule zoom = BiggestBeautyClient.moduleManager.getModule(ZoomModule.class);
        if (zoom != null && zoom.getKeybind() != Keyboard.KEY_NONE) {
            boolean held = mc.field_71462_r == null && Keyboard.isKeyDown(zoom.getKeybind());
            zoom.setZooming(held);
        }

        ParticleTrailModule trail = BiggestBeautyClient.moduleManager.getModule(ParticleTrailModule.class);
        if (trail != null) {
            trail.onClientTick();
        }

        PingGraphHud pingGraph = BiggestBeautyClient.moduleManager.getModule(PingGraphHud.class);
        if (pingGraph != null) {
            pingGraph.onClientTick();
        }

        FullbrightModule fullbright = BiggestBeautyClient.moduleManager.getModule(FullbrightModule.class);
        if (fullbright != null && fullbright.isEnabled()) {
            fullbright.applyGamma();
        }

        AutoSprintModule autoSprint = BiggestBeautyClient.moduleManager.getModule(AutoSprintModule.class);
        if (autoSprint != null) {
            autoSprint.onClientTick();
        }

        AntiAfkModule antiAfk = BiggestBeautyClient.moduleManager.getModule(AntiAfkModule.class);
        if (antiAfk != null) {
            antiAfk.onClientTick();
        }

        AutoRespawnModule autoRespawn = BiggestBeautyClient.moduleManager.getModule(AutoRespawnModule.class);
        if (autoRespawn != null) {
            autoRespawn.onClientTick();
        }

        VelocityHud velocity = BiggestBeautyClient.moduleManager.getModule(VelocityHud.class);
        if (velocity != null) {
            velocity.onClientTick();
        }

        ArrowTrailModule arrowTrail = BiggestBeautyClient.moduleManager.getModule(ArrowTrailModule.class);
        if (arrowTrail != null) {
            arrowTrail.onClientTick();
        }

        LevelUpEffectModule levelUp = BiggestBeautyClient.moduleManager.getModule(LevelUpEffectModule.class);
        if (levelUp != null) {
            levelUp.onClientTick();
        }

        fpsSampleCounter++;
        if (fpsSampleCounter >= 20) {
            fpsSampleCounter = 0;
            NetOptimizerModule netOptimizer = BiggestBeautyClient.moduleManager.getModule(NetOptimizerModule.class);
            if (netOptimizer != null && netOptimizer.isEnabled()) {
                netOptimizer.onFpsSample(Minecraft.func_175610_ah());
            }
        }
    }
}
