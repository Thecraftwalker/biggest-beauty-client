package com.biggestbeauty.client.event;

import com.biggestbeauty.client.BiggestBeautyClient;
import com.biggestbeauty.client.module.impl.cosmetic.DamageIndicatorModule;
import com.biggestbeauty.client.module.impl.hud.TntTimerModule;
import com.biggestbeauty.client.module.impl.render.DroppedItemHighlightModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.util.AxisAlignedBB;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.List;

public class WorldRenderHandler {

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71441_e == null || mc.field_71439_g == null) return;

        EntityPlayerSP player = mc.field_71439_g;
        double renderX = player.field_70142_S + (player.field_70165_t - player.field_70142_S) * event.partialTicks;
        double renderY = player.field_70137_T + (player.field_70163_u - player.field_70137_T) * event.partialTicks;
        double renderZ = player.field_70136_U + (player.field_70161_v - player.field_70136_U) * event.partialTicks;

        renderTntTimers(mc, player, renderX, renderY, renderZ, event.partialTicks);
        renderDamageIndicators(mc, renderX, renderY, renderZ, event.partialTicks);
        renderItemHighlights(mc, player, renderX, renderY, renderZ);
    }

    private void renderTntTimers(Minecraft mc, EntityPlayerSP player, double renderX, double renderY, double renderZ, float partialTicks) {
        TntTimerModule tntTimer = BiggestBeautyClient.moduleManager.getModule(TntTimerModule.class);
        if (tntTimer == null || !tntTimer.isEnabled()) return;

        AxisAlignedBB searchBox = player.func_174813_aQ().func_72314_b(48, 48, 48);
        List<EntityTNTPrimed> tntList = mc.field_71441_e.func_72872_a(EntityTNTPrimed.class, searchBox);

        for (EntityTNTPrimed tnt : tntList) {
            double tx = tnt.field_70142_S + (tnt.field_70165_t - tnt.field_70142_S) * partialTicks;
            double ty = tnt.field_70137_T + (tnt.field_70163_u - tnt.field_70137_T) * partialTicks + 1.0;
            double tz = tnt.field_70136_U + (tnt.field_70161_v - tnt.field_70136_U) * partialTicks;

            drawLabel(tntTimer.formatFuse(tnt), tx - renderX, ty - renderY, tz - renderZ, mc, RenderUtil.THEME_ACCENT_2);
        }
    }

    private void renderDamageIndicators(Minecraft mc, double renderX, double renderY, double renderZ, float partialTicks) {
        DamageIndicatorModule indicators = BiggestBeautyClient.moduleManager.getModule(DamageIndicatorModule.class);
        if (indicators == null || !indicators.isEnabled()) return;

        int color = indicators.getColor();

        for (DamageIndicatorModule.Indicator indicator : indicators.getActive()) {
            Entity entity = mc.field_71441_e.func_73045_a(indicator.entityId);
            if (entity == null) continue;

            float age = (System.currentTimeMillis() - indicator.createdAt) / 800f;
            double ex = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * partialTicks;
            double ey = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * partialTicks
                    + entity.field_70131_O + 0.3 + age * 0.5;
            double ez = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * partialTicks;

            String text = String.format("-%.1f", indicator.amount);
            drawLabel(text, ex - renderX, ey - renderY, ez - renderZ, mc, color);
        }
    }

    private void renderItemHighlights(Minecraft mc, EntityPlayerSP player, double renderX, double renderY, double renderZ) {
        DroppedItemHighlightModule highlight = BiggestBeautyClient.moduleManager.getModule(DroppedItemHighlightModule.class);
        if (highlight == null || !highlight.isEnabled()) return;

        AxisAlignedBB searchBox = player.func_174813_aQ().func_72314_b(32, 32, 32);
        List<EntityItem> items = mc.field_71441_e.func_72872_a(EntityItem.class, searchBox);

        for (EntityItem item : items) {
            double ix = item.field_70165_t - renderX;
            double iy = item.field_70163_u - renderY;
            double iz = item.field_70161_v - renderZ;

            GlStateManager.func_179094_E();
            GlStateManager.func_179137_b(ix, iy + 0.15, iz);
            GlStateManager.func_179114_b(-mc.func_175598_ae().field_78735_i, 0, 1, 0);
            GlStateManager.func_179114_b(mc.func_175598_ae().field_78732_j, 1, 0, 0);

            GlStateManager.func_179140_f();
            GlStateManager.func_179132_a(false);
            GlStateManager.func_179097_i();
            GlStateManager.func_179147_l();
            GlStateManager.func_179120_a(770, 771, 1, 0);

            float half = 0.35f;
            RenderUtil.drawOutline((int) -(half * 40), (int) -(half * 40), (int) (half * 40), (int) (half * 40), RenderUtil.THEME_ACCENT, 1);

            GlStateManager.func_179126_j();
            GlStateManager.func_179132_a(true);
            GlStateManager.func_179084_k();
            GlStateManager.func_179145_e();
            GlStateManager.func_179121_F();
        }
    }

    private void drawLabel(String text, double x, double y, double z, Minecraft mc, int color) {
        FontRenderer fr = mc.field_71466_p;
        float scale = 0.02F;

        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b(x, y, z);
        GlStateManager.func_179114_b(-mc.func_175598_ae().field_78735_i, 0, 1, 0);
        GlStateManager.func_179114_b(mc.func_175598_ae().field_78732_j, 1, 0, 0);
        GlStateManager.func_179152_a(-scale, -scale, scale);

        GlStateManager.func_179140_f();
        GlStateManager.func_179132_a(false);
        GlStateManager.func_179097_i();
        GlStateManager.func_179147_l();
        GlStateManager.func_179120_a(770, 771, 1, 0);

        int width = fr.func_78256_a(text);
        RenderUtil.drawRect(-width / 2 - 2, -1, width / 2 + 2, 9, 0x80000000);
        fr.func_78276_b(text, -width / 2, 0, color);

        GlStateManager.func_179126_j();
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179084_k();
        GlStateManager.func_179145_e();
        GlStateManager.func_179121_F();
    }
}
