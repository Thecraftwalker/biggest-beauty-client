package com.biggestbeauty.client.gui;

import com.biggestbeauty.client.BiggestBeautyClient;
import com.biggestbeauty.client.gui.tab.Tab;
import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;
import com.biggestbeauty.client.util.ClientConfig;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ClientGui extends GuiScreen {

    private static final int SIDEBAR_WIDTH = 130;
    private static final int TAB_HEIGHT = 28;
    private static final int ROW_HEIGHT = 22;
    private static final int SETTING_ROW_HEIGHT = 18;
    private static final int LIST_TOP = 40;
    private static final int LIST_WIDTH = 300;

    private Tab currentTab = Tab.HOME;
    private Category currentModsCategory = Category.HUD;

    private GuiTextField clientNameField;
    private GuiTextField profileNameField;
    private final Map<Setting, GuiTextField> textFields = new HashMap<>();
    private final Set<Module> expanded = new HashSet<>();

    private int scrollOffset = 0;
    private Setting draggingSlider = null;

    private String statusMessage = "";
    private long statusMessageUntil = 0;

    private static final net.minecraft.util.ResourceLocation LOGO =
            new net.minecraft.util.ResourceLocation("biggestbeauty", "textures/gui/logo.png");

    @Override
    public void func_73866_w_() {
        clientNameField = new GuiTextField(0, field_146289_q, 0, 0, 160, 16);
        clientNameField.func_146203_f(32);
        clientNameField.func_146180_a(BiggestBeautyClient.instance.config.clientName);

        profileNameField = new GuiTextField(1, field_146289_q, 0, 0, 160, 16);
        profileNameField.func_146203_f(24);
        profileNameField.func_146180_a("My Profile");
    }

    private void flashStatus(String message) {
        statusMessage = message;
        statusMessageUntil = System.currentTimeMillis() + 2000;
    }

    private void setTab(Tab tab) {
        if (tab != currentTab) scrollOffset = 0;
        currentTab = tab;
    }

    private void setCategory(Category c) {
        if (c != currentModsCategory) scrollOffset = 0;
        currentModsCategory = c;
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        RenderUtil.drawRect(0, 0, field_146294_l, field_146295_m, 0xCC0E0A14);

        drawSidebar(mouseX, mouseY);

        int contentX = SIDEBAR_WIDTH + 16;
        switch (currentTab) {
            case HOME:
                drawHome(contentX);
                break;
            case MODS:
                drawModsTab(contentX, mouseX, mouseY, Category.HUD, Category.RENDER, Category.PERFORMANCE, Category.MEDIA, Category.MISC);
                break;
            case COSMETICS:
                drawModsTab(contentX, mouseX, mouseY, Category.COSMETIC);
                break;
            case PROFILE:
                drawProfileTab(contentX, mouseX, mouseY);
                break;
            case SETTINGS:
                drawSettingsTab(contentX, mouseX, mouseY);
                break;
        }

        if (System.currentTimeMillis() < statusMessageUntil) {
            field_146289_q.func_175063_a(statusMessage, contentX, field_146295_m - 20, RenderUtil.THEME_ACCENT_2);
        }

        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    private void drawSidebar(int mouseX, int mouseY) {
        RenderUtil.drawRect(0, 0, SIDEBAR_WIDTH, field_146295_m, 0xE6141018);

        field_146297_k.func_110434_K().func_110577_a(LOGO);
        net.minecraft.client.renderer.GlStateManager.func_179131_c(1f, 1f, 1f, 1f);
        func_152125_a(10, 8, 0, 0, 256, 256, 22, 22, 256, 256);

        String name = BiggestBeautyClient.instance.config.clientName;
        field_146289_q.func_175063_a(name.length() > 16 ? "Biggest Beauty" : name, 38, 14, RenderUtil.THEME_ACCENT);

        int y = 40;
        for (Tab tab : Tab.values()) {
            boolean hovered = mouseX >= 0 && mouseX <= SIDEBAR_WIDTH && mouseY >= y && mouseY <= y + TAB_HEIGHT;
            boolean selected = tab == currentTab;
            if (selected) {
                RenderUtil.drawRect(0, y, SIDEBAR_WIDTH, y + TAB_HEIGHT, 0x40F2A6D6);
                RenderUtil.drawRect(0, y, 3, y + TAB_HEIGHT, RenderUtil.THEME_ACCENT);
            } else if (hovered) {
                RenderUtil.drawRect(0, y, SIDEBAR_WIDTH, y + TAB_HEIGHT, 0x22FFFFFF);
            }
            int color = selected ? 0xFFFFFFFF : 0xFFAAAAAA;
            field_146289_q.func_175063_a(tab.getDisplay(), 14, y + 10, color);
            y += TAB_HEIGHT;
        }

        String username = field_146297_k.func_110432_I() != null ? field_146297_k.func_110432_I().func_111285_a() : "Player";
        field_146289_q.func_175063_a(username, 10, field_146295_m - 20, 0xFF888888);
    }

    private void drawHome(int x) {
        String title = BiggestBeautyClient.instance.config.clientName;
        field_146289_q.func_175063_a(title, x, 20, RenderUtil.THEME_ACCENT);
        field_146289_q.func_175063_a("v" + BiggestBeautyClient.VERSION + " - Forge 1.8.9", x, 34, 0xFF888888);

        String username = field_146297_k.func_110432_I() != null ? field_146297_k.func_110432_I().func_111285_a() : "Player";
        field_146289_q.func_175063_a("Logged in as: " + username, x, 56, 0xFFFFFFFF);

        List<Module> all = BiggestBeautyClient.moduleManager.getModules();
        int enabledCount = 0;
        for (Module m : all) if (m.isEnabled()) enabledCount++;

        int cardY = 76;
        drawStatCard(x, cardY, "FPS", String.valueOf(net.minecraft.client.Minecraft.func_175610_ah()));
        drawStatCard(x + 100, cardY, "Modules On", enabledCount + " / " + all.size());
        drawStatCard(x + 200, cardY, "Categories", String.valueOf(Category.values().length));

        int listY = cardY + 46;
        field_146289_q.func_175063_a("Currently enabled:", x, listY, RenderUtil.THEME_ACCENT_2);
        listY += 12;
        boolean any = false;
        for (Module m : all) {
            if (!m.isEnabled()) continue;
            any = true;
            field_146289_q.func_175063_a("- " + m.getName() + " (" + m.getCategory().getDisplay() + ")", x, listY, 0xFFCCCCCC);
            listY += 10;
        }
        if (!any) {
            field_146289_q.func_175063_a("(nothing enabled yet - check the Mods tab)", x, listY, 0xFF777777);
            listY += 10;
        }

        listY += 10;
        field_146289_q.func_175063_a("Right Shift to open/close this menu.", x, listY, 0xFF777777);
        field_146289_q.func_175063_a("Click a mod's name in Mods/Cosmetics to toggle it; the small gear opens its settings.", x, listY + 12, 0xFF777777);
        field_146289_q.func_175063_a("Settings > Open HUD Editor to drag your on-screen HUD elements around.", x, listY + 24, 0xFF777777);
    }

    private void drawStatCard(int x, int y, String label, String value) {
        int w = 92, h = 40;
        RenderUtil.drawRect(x, y, x + w, y + h, RenderUtil.THEME_BG);
        RenderUtil.drawOutline(x, y, x + w, y + h, 0xFF2A2432, 1);
        field_146289_q.func_175063_a(label, x + 6, y + 6, 0xFF999999);
        field_146289_q.func_175063_a(value, x + 6, y + 20, 0xFFFFFFFF);
    }

    private int rowHeightFor(Module m) {
        int h = ROW_HEIGHT;
        if (expanded.contains(m) && !m.getSettings().isEmpty()) {
            h += m.getSettings().size() * SETTING_ROW_HEIGHT + 4;
        }
        return h;
    }

    private int totalContentHeight(List<Module> modules) {
        int total = 0;
        for (Module m : modules) total += rowHeightFor(m);
        return total;
    }

    private void drawModsTab(int x, int mouseX, int mouseY, Category... categories) {
        int catX = x;
        for (Category c : categories) {
            boolean selected = c == currentModsCategory;
            int w = field_146289_q.func_78256_a(c.getDisplay()) + 16;
            boolean hovered = mouseX >= catX && mouseX <= catX + w && mouseY >= 14 && mouseY <= 30;
            if (selected) RenderUtil.drawRect(catX, 14, catX + w, 30, 0x40F2A6D6);
            else if (hovered) RenderUtil.drawRect(catX, 14, catX + w, 30, 0x22FFFFFF);
            field_146289_q.func_175063_a(c.getDisplay(), catX + 8, 20, selected ? 0xFFFFFFFF : 0xFFAAAAAA);
            catX += w + 6;
        }

        boolean valid = false;
        for (Category c : categories) if (c == currentModsCategory) valid = true;
        if (!valid) currentModsCategory = categories[0];

        int contentBottom = field_146295_m - 30;
        List<Module> modules = BiggestBeautyClient.moduleManager.getModulesByCategory(currentModsCategory);

        int maxScroll = Math.max(0, totalContentHeight(modules) - (contentBottom - LIST_TOP));
        if (scrollOffset > maxScroll) scrollOffset = maxScroll;
        if (scrollOffset < 0) scrollOffset = 0;

        int y = LIST_TOP - scrollOffset;
        for (Module m : modules) {
            int rowH = rowHeightFor(m);
            if (y + rowH >= LIST_TOP && y <= contentBottom) {
                drawModuleRow(x, y, m, mouseX, mouseY);
            }
            y += rowH;
        }

        if (maxScroll > 0) {
            int trackX = x + LIST_WIDTH + 10;
            RenderUtil.drawRect(trackX, LIST_TOP, trackX + 4, contentBottom, 0xFF221C2A);
            int trackH = contentBottom - LIST_TOP;
            int thumbH = Math.max(20, trackH * trackH / (trackH + maxScroll));
            int thumbY = LIST_TOP + (int) ((trackH - thumbH) * (scrollOffset / (float) maxScroll));
            RenderUtil.drawRect(trackX, thumbY, trackX + 4, thumbY + thumbH, RenderUtil.THEME_ACCENT);
        }
    }

    private void drawModuleRow(int x, int y, Module m, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + LIST_WIDTH && mouseY >= y && mouseY <= y + ROW_HEIGHT - 2;
        if (hovered) RenderUtil.drawRect(x, y, x + LIST_WIDTH, y + ROW_HEIGHT - 2, 0x1AFFFFFF);

        field_146289_q.func_175063_a(m.getName(), x + 6, y + 6, m.isEnabled() ? 0xFFFFFFFF : 0xFFAAAAAA);

        boolean hasSettings = !m.getSettings().isEmpty();
        if (hasSettings) {
            boolean gearHovered = mouseX >= x + 210 && mouseX <= x + 228 && mouseY >= y + 3 && mouseY <= y + 19;
            int gearColor = expanded.contains(m) ? RenderUtil.THEME_ACCENT : (gearHovered ? 0xFFFFFFFF : 0xFF888888);
            field_146289_q.func_175063_a("\u2699", x + 213, y + 6, gearColor);
        }

        drawToggleSwitch(x + LIST_WIDTH - 40, y + 4, m.isEnabled());

        if (expanded.contains(m) && hasSettings) {
            int sy = y + ROW_HEIGHT;
            for (Setting s : m.getSettings()) {
                drawSettingRow(x + 16, sy, s, mouseX, mouseY);
                sy += SETTING_ROW_HEIGHT;
            }
        }
    }

    private void drawSettingRow(int x, int y, Setting s, int mouseX, int mouseY) {
        field_146289_q.func_175063_a(s.getName(), x, y + 5, 0xFFAAAAAA);
        int controlX = x + 90;

        switch (s.getType()) {
            case BOOLEAN: {
                drawToggleSwitch(controlX, y + 2, s.getBool());
                break;
            }
            case SLIDER: {
                int barW = 100;
                RenderUtil.drawRect(controlX, y + 6, controlX + barW, y + 9, 0xFF2A2432);
                int knobX = controlX + (int) (s.getSliderFraction() * (barW - 6));
                RenderUtil.drawRect(knobX, y + 3, knobX + 6, y + 12, RenderUtil.THEME_ACCENT);
                String valText = s.isWholeNumbers() ? String.valueOf(Math.round(s.getSlider())) : String.format("%.1f", s.getSlider());
                field_146289_q.func_175063_a(valText, controlX + barW + 8, y + 5, 0xFFFFFFFF);
                break;
            }
            case TEXT: {
                GuiTextField field = textFields.computeIfAbsent(s, k -> {
                    GuiTextField f = new GuiTextField(0, fontRendererObj, 0, 0, 120, 14);
                    f.setMaxStringLength(48);
                    f.setText(s.getText() != null ? s.getText() : "");
                    return f;
                });
                field.field_146209_f = controlX;
                field.field_146210_g = y + 1;
                field.func_146194_f();
                break;
            }
        }
    }

    private void drawToggleSwitch(int x, int y, boolean on) {
        int w = 28, h = 14;
        int bg = on ? RenderUtil.THEME_ACCENT : 0xFF3A3540;
        RenderUtil.drawRect(x, y, x + w, y + h, bg);
        int knobX = on ? x + w - h : x;
        RenderUtil.drawRect(knobX, y, knobX + h, y + h, 0xFFFFFFFF);
    }

    private void drawProfileTab(int x, int mouseX, int mouseY) {
        field_146289_q.func_175063_a("Profile", x, 20, RenderUtil.THEME_ACCENT);
        String username = field_146297_k.func_110432_I() != null ? field_146297_k.func_110432_I().func_111285_a() : "Player";
        field_146289_q.func_175063_a("Account: " + username, x, 40, 0xFFFFFFFF);

        field_146289_q.func_175063_a("Save current module setup as a profile:", x, 66, 0xFFCCCCCC);
        profileNameField.field_146209_f = x;
        profileNameField.field_146210_g = 80;
        profileNameField.func_146194_f();

        int saveBtnX = x + 168;
        boolean hoveredSave = mouseX >= saveBtnX && mouseX <= saveBtnX + 60 && mouseY >= 78 && mouseY <= 96;
        RenderUtil.drawRect(saveBtnX, 78, saveBtnX + 60, 96, hoveredSave ? RenderUtil.THEME_ACCENT : 0xFF2A2432);
        field_146289_q.func_175063_a("Save", saveBtnX + 18, 83, 0xFFFFFFFF);

        field_146289_q.func_175063_a("Saved profiles:", x, 110, 0xFFCCCCCC);
        String[] profiles = ClientConfig.listProfiles();
        int y = 124;
        for (String p : profiles) {
            boolean hovered = mouseX >= x && mouseX <= x + 200 && mouseY >= y && mouseY <= y + ROW_HEIGHT - 2;
            if (hovered) RenderUtil.drawRect(x, y, x + 200, y + ROW_HEIGHT - 2, 0x1AFFFFFF);
            field_146289_q.func_175063_a(p, x + 6, y + 6, 0xFFFFFFFF);
            field_146289_q.func_175063_a("[load]", x + 150, y + 6, RenderUtil.THEME_ACCENT_2);
            y += ROW_HEIGHT;
        }
        if (profiles.length == 0) {
            field_146289_q.func_175063_a("(none yet)", x, y, 0xFF777777);
        }
    }

    private void drawSettingsTab(int x, int mouseX, int mouseY) {
        field_146289_q.func_175063_a("Settings", x, 20, RenderUtil.THEME_ACCENT);

        field_146289_q.func_175063_a("Client name:", x, 44, 0xFFCCCCCC);
        clientNameField.field_146209_f = x;
        clientNameField.field_146210_g = 56;
        clientNameField.func_146194_f();

        int applyBtnX = x + 168;
        boolean hoveredApply = mouseX >= applyBtnX && mouseX <= applyBtnX + 60 && mouseY >= 54 && mouseY <= 72;
        RenderUtil.drawRect(applyBtnX, 54, applyBtnX + 60, 72, hoveredApply ? RenderUtil.THEME_ACCENT : 0xFF2A2432);
        field_146289_q.func_175063_a("Apply", applyBtnX + 14, 59, 0xFFFFFFFF);

        int hudBtnY = 96;
        boolean hoveredHud = mouseX >= x && mouseX <= x + 150 && mouseY >= hudBtnY && mouseY <= hudBtnY + 20;
        RenderUtil.drawRect(x, hudBtnY, x + 150, hudBtnY + 20, hoveredHud ? RenderUtil.THEME_ACCENT : 0xFF2A2432);
        field_146289_q.func_175063_a("Open HUD Editor", x + 8, hudBtnY + 6, 0xFFFFFFFF);

        field_146289_q.func_175063_a("Drag any HUD element around the screen, then press", x, hudBtnY + 28, 0xFF888888);
        field_146289_q.func_175063_a("Escape to save its position and return here.", x, hudBtnY + 40, 0xFF888888);

        int resetBtnY = hudBtnY + 58;
        boolean hoveredReset = mouseX >= x && mouseX <= x + 150 && mouseY >= resetBtnY && mouseY <= resetBtnY + 20;
        RenderUtil.drawRect(x, resetBtnY, x + 150, resetBtnY + 20, hoveredReset ? 0xFFF25C5C : 0xFF2A2432);
        field_146289_q.func_175063_a("Reset All Modules", x + 8, resetBtnY + 6, 0xFFFFFFFF);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws java.io.IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);

        clientNameField.func_146192_a(mouseX, mouseY, mouseButton);
        profileNameField.func_146192_a(mouseX, mouseY, mouseButton);
        for (GuiTextField field : textFields.values()) {
            field.func_146192_a(mouseX, mouseY, mouseButton);
        }

        int y = 40;
        for (Tab tab : Tab.values()) {
            if (mouseX >= 0 && mouseX <= SIDEBAR_WIDTH && mouseY >= y && mouseY <= y + TAB_HEIGHT) {
                setTab(tab);
                return;
            }
            y += TAB_HEIGHT;
        }

        int x = SIDEBAR_WIDTH + 16;

        if (currentTab == Tab.MODS || currentTab == Tab.COSMETICS) {
            Category[] cats = currentTab == Tab.MODS
                    ? new Category[]{Category.HUD, Category.RENDER, Category.PERFORMANCE, Category.MEDIA, Category.MISC}
                    : new Category[]{Category.COSMETIC};

            int catX = x;
            for (Category c : cats) {
                int w = field_146289_q.func_78256_a(c.getDisplay()) + 16;
                if (mouseX >= catX && mouseX <= catX + w && mouseY >= 14 && mouseY <= 30) {
                    setCategory(c);
                    return;
                }
                catX += w + 6;
            }

            List<Module> modules = BiggestBeautyClient.moduleManager.getModulesByCategory(currentModsCategory);
            int rowY = LIST_TOP - scrollOffset;
            for (Module m : modules) {
                int rowH = rowHeightFor(m);

                if (!m.getSettings().isEmpty() && mouseX >= x + 210 && mouseX <= x + 228 && mouseY >= rowY + 3 && mouseY <= rowY + 19) {
                    if (expanded.contains(m)) expanded.remove(m);
                    else expanded.add(m);
                    return;
                }

                if (mouseX >= x && mouseX <= x + LIST_WIDTH && mouseY >= rowY && mouseY <= rowY + ROW_HEIGHT - 2) {
                    m.toggle();
                    BiggestBeautyClient.moduleManager.notifyToggle(m);
                    BiggestBeautyClient.instance.config.save();
                    return;
                }

                if (expanded.contains(m) && !m.getSettings().isEmpty()) {
                    int sy = rowY + ROW_HEIGHT;
                    for (Setting s : m.getSettings()) {
                        if (handleSettingClick(x + 16, sy, s, mouseX, mouseY, m)) return;
                        sy += SETTING_ROW_HEIGHT;
                    }
                }

                rowY += rowH;
            }
        }

        if (currentTab == Tab.PROFILE) {
            int saveBtnX = x + 168;
            if (mouseX >= saveBtnX && mouseX <= saveBtnX + 60 && mouseY >= 78 && mouseY <= 96) {
                String name = profileNameField.func_146179_b().trim();
                if (!name.isEmpty()) {
                    BiggestBeautyClient.instance.config.saveProfile(name);
                    flashStatus("Saved profile '" + name + "'");
                }
                return;
            }

            String[] profiles = ClientConfig.listProfiles();
            int rowY = 124;
            for (String p : profiles) {
                if (mouseX >= x && mouseX <= x + 200 && mouseY >= rowY && mouseY <= rowY + ROW_HEIGHT - 2) {
                    ClientConfig loaded = ClientConfig.loadProfile(p);
                    if (loaded != null) {
                        loaded.applyToModules();
                        BiggestBeautyClient.instance.config.clientName = loaded.clientName;
                        clientNameField.func_146180_a(loaded.clientName);
                        flashStatus("Loaded profile '" + p + "'");
                    }
                    return;
                }
                rowY += ROW_HEIGHT;
            }
        }

        if (currentTab == Tab.SETTINGS) {
            int applyBtnX = x + 168;
            if (mouseX >= applyBtnX && mouseX <= applyBtnX + 60 && mouseY >= 54 && mouseY <= 72) {
                String newName = clientNameField.func_146179_b().trim();
                if (!newName.isEmpty()) {
                    BiggestBeautyClient.instance.config.clientName = newName;
                    org.lwjgl.opengl.Display.setTitle(newName);
                    BiggestBeautyClient.instance.config.save();
                    flashStatus("Client renamed to '" + newName + "'");
                }
                return;
            }

            int hudBtnY = 96;
            if (mouseX >= x && mouseX <= x + 150 && mouseY >= hudBtnY && mouseY <= hudBtnY + 20) {
                field_146297_k.func_147108_a(new HudEditorGui());
                return;
            }

            int resetBtnY = hudBtnY + 58;
            if (mouseX >= x && mouseX <= x + 150 && mouseY >= resetBtnY && mouseY <= resetBtnY + 20) {
                for (Module m : BiggestBeautyClient.moduleManager.getModules()) {
                    m.setEnabled(false);
                }
                BiggestBeautyClient.instance.config.save();
                flashStatus("All modules disabled");
                return;
            }
        }
    }

    private boolean handleSettingClick(int x, int y, Setting s, int mouseX, int mouseY, Module owner) {
        int controlX = x + 90;
        switch (s.getType()) {
            case BOOLEAN: {
                if (mouseX >= controlX && mouseX <= controlX + 28 && mouseY >= y + 2 && mouseY <= y + 16) {
                    s.toggleBool();
                    owner.onSettingChanged(s);
                    BiggestBeautyClient.instance.config.save();
                    return true;
                }
                return false;
            }
            case SLIDER: {
                int barW = 100;
                if (mouseX >= controlX && mouseX <= controlX + barW && mouseY >= y && mouseY <= y + SETTING_ROW_HEIGHT) {
                    draggingSlider = s;
                    updateDraggedSlider(controlX, barW, mouseX, owner);
                    return true;
                }
                return false;
            }
            case TEXT: {
                GuiTextField field = textFields.get(s);
                if (field != null && mouseX >= controlX && mouseX <= controlX + 120 && mouseY >= y && mouseY <= y + 16) {
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    private void updateDraggedSlider(int controlX, int barW, int mouseX, Module owner) {
        float fraction = (mouseX - controlX) / (float) barW;
        draggingSlider.setSliderFraction(fraction);
        owner.onSettingChanged(draggingSlider);
    }

    @Override
    protected void func_146286_b(int mouseX, int mouseY, int state) {
        super.func_146286_b(mouseX, mouseY, state);
        if (draggingSlider != null) {
            BiggestBeautyClient.instance.config.save();
        }
        draggingSlider = null;
    }

    @Override
    public void func_146274_d() throws java.io.IOException {
        super.func_146274_d();

        if (draggingSlider != null && org.lwjgl.input.Mouse.isButtonDown(0)) {
            int mouseX = org.lwjgl.input.Mouse.getEventX() * field_146294_l / field_146297_k.field_71443_c;
            Module owner = findOwner(draggingSlider);
            int x = SIDEBAR_WIDTH + 16 + 16;
            int controlX = x + 90;
            int barW = 100;
            if (owner != null) updateDraggedSlider(controlX, barW, mouseX, owner);
        }

        int dWheel = org.lwjgl.input.Mouse.getEventDWheel();
        if (dWheel != 0 && (currentTab == Tab.MODS || currentTab == Tab.COSMETICS)) {
            scrollOffset -= Integer.signum(dWheel) * ROW_HEIGHT;
            if (scrollOffset < 0) scrollOffset = 0;
        }
    }

    private Module findOwner(Setting setting) {
        for (Module m : BiggestBeautyClient.moduleManager.getModules()) {
            if (m.getSettings().contains(setting)) return m;
        }
        return null;
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws java.io.IOException {
        if (keyCode == 1) {
            field_146297_k.func_147108_a(null);
            return;
        }
        if (clientNameField.func_146206_l()) {
            clientNameField.func_146201_a(typedChar, keyCode);
            return;
        }
        if (profileNameField.func_146206_l()) {
            profileNameField.func_146201_a(typedChar, keyCode);
            return;
        }
        for (Map.Entry<Setting, GuiTextField> entry : textFields.entrySet()) {
            if (entry.getValue().func_146206_l()) {
                entry.getValue().func_146201_a(typedChar, keyCode);
                entry.getKey().setText(entry.getValue().func_146179_b());
                Module owner = findOwner(entry.getKey());
                if (owner != null) owner.onSettingChanged(entry.getKey());
                return;
            }
        }
        super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public void func_73876_c() {
        clientNameField.func_146178_a();
        profileNameField.func_146178_a();
        for (GuiTextField f : textFields.values()) f.func_146178_a();
    }

    @Override
    public void func_146281_b() {
        BiggestBeautyClient.instance.config.save();
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }
}
