package com.biggestbeauty.client.gui;

import com.biggestbeauty.client.BiggestBeautyClient;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;

import java.util.List;

public class HudEditorGui extends GuiScreen {

    private HudModule dragging = null;
    private int dragOffsetX, dragOffsetY;

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution sr = new ScaledResolution(field_146297_k);

        List<HudModule> modules = BiggestBeautyClient.moduleManager.getHudModules();
        for (HudModule m : modules) {
            m.render(sr, true);
        }

        String hint = "Drag elements to reposition - Escape to save & exit";
        int hintWidth = field_146289_q.func_78256_a(hint);
        RenderUtil.drawRect(field_146294_l / 2 - hintWidth / 2 - 6, 6, field_146294_l / 2 + hintWidth / 2 + 6, 20, 0xB0141018);
        field_146289_q.func_175063_a(hint, field_146294_l / 2 - hintWidth / 2, 10, RenderUtil.THEME_ACCENT_2);

        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws java.io.IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);
        if (mouseButton != 0) return;

        ScaledResolution sr = new ScaledResolution(field_146297_k);
        List<HudModule> modules = BiggestBeautyClient.moduleManager.getHudModules();

        for (int i = modules.size() - 1; i >= 0; i--) {
            HudModule m = modules.get(i);
            int x = m.getX(sr);
            int y = m.getY(sr);
            if (mouseX >= x - 2 && mouseX <= x + m.getWidth() + 2 && mouseY >= y - 2 && mouseY <= y + m.getHeight() + 2) {
                dragging = m;
                dragOffsetX = mouseX - x;
                dragOffsetY = mouseY - y;
                return;
            }
        }
    }

    @Override
    protected void func_146286_b(int mouseX, int mouseY, int state) {
        super.func_146286_b(mouseX, mouseY, state);
        dragging = null;
    }

    @Override
    public void func_146274_d() throws java.io.IOException {
        super.func_146274_d();
        if (dragging == null) return;

        int mouseX = org.lwjgl.input.Mouse.getEventX() * field_146294_l / field_146297_k.field_71443_c;
        int mouseY = field_146295_m - org.lwjgl.input.Mouse.getEventY() * field_146295_m / field_146297_k.field_71440_d - 1;

        if (!org.lwjgl.input.Mouse.isButtonDown(0)) {
            dragging = null;
            return;
        }

        ScaledResolution sr = new ScaledResolution(field_146297_k);
        int newX = mouseX - dragOffsetX;
        int newY = mouseY - dragOffsetY;
        dragging.setPosition(sr, newX, newY);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws java.io.IOException {
        if (keyCode == 1) {
            BiggestBeautyClient.instance.config.save();
            field_146297_k.func_147108_a(new ClientGui());
            return;
        }
        super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }
}
