package com.biggestbeauty.client.gui.tab;

public enum Tab {
    HOME("Home"),
    MODS("Mods"),
    COSMETICS("Cosmetics"),
    PROFILE("Profile"),
    SETTINGS("Settings");

    private final String display;

    Tab(String display) {
        this.display = display;
    }

    public String getDisplay() {
        return display;
    }
}
