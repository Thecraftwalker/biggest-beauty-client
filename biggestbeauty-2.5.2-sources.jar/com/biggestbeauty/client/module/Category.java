package com.biggestbeauty.client.module;

public enum Category {
    HUD("HUD"),
    RENDER("Render"),
    PERFORMANCE("Performance"),
    COSMETIC("Cosmetic"),
    MEDIA("Media"),
    MISC("Misc");

    private final String display;

    Category(String display) {
        this.display = display;
    }

    public String getDisplay() {
        return display;
    }
}
