package com.biggestbeauty.client.module;

import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public abstract class HudModule extends Module {

    protected float relX;
    protected float relY;

    public HudModule(String name, Category category, int keybind, boolean enabledByDefault, float relX, float relY) {
        super(name, category, keybind, enabledByDefault);
        this.relX = relX;
        this.relY = relY;
    }

    public abstract int getWidth();

    public abstract int getHeight();

    public abstract void render(ScaledResolution sr, boolean edit);

    public int getX(ScaledResolution sr) {
        return (int) (relX * sr.func_78326_a()) - getWidth();
    }

    public int getY(ScaledResolution sr) {
        return (int) (relY * sr.func_78328_b());
    }

    public void setPosition(ScaledResolution sr, int x, int y) {
        this.relX = (float) (x + getWidth()) / sr.func_78326_a();
        this.relY = (float) y / sr.func_78328_b();
        clamp();
    }

    private void clamp() {
        if (relX < 0f) relX = 0f;
        if (relX > 1f) relX = 1f;
        if (relY < 0f) relY = 0f;
        if (relY > 1f) relY = 1f;
    }

    protected void drawEditBox(ScaledResolution sr) {
        int x = getX(sr);
        int y = getY(sr);
        RenderUtil.drawRect(x - 2, y - 2, x + getWidth() + 2, y + getHeight() + 2, 0x5AF2A6D6);
        RenderUtil.drawOutline(x - 2, y - 2, x + getWidth() + 2, y + getHeight() + 2, RenderUtil.THEME_ACCENT_2, 1);
    }

    public float getRelX() {
        return relX;
    }

    public float getRelY() {
        return relY;
    }

    public void setRelX(float relX) {
        this.relX = relX;
    }

    public void setRelY(float relY) {
        this.relY = relY;
    }
}
