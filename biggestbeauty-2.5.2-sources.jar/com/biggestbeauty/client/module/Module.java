package com.biggestbeauty.client.module;

import net.minecraft.client.Minecraft;

public abstract class Module {

    protected final Minecraft mc = Minecraft.func_71410_x();

    private final String name;
    private final Category category;
    private int keybind;
    private boolean enabled;
    private final java.util.List<Setting> settings = new java.util.ArrayList<>();

    public Module(String name, Category category, int keybind, boolean enabledByDefault) {
        this.name = name;
        this.category = category;
        this.keybind = keybind;
        this.enabled = enabledByDefault;
        if (enabledByDefault) {
            onEnable();
        }
    }

    public Module(String name, Category category) {
        this(name, category, 0, false);
    }

    public void toggle() {
        enabled = !enabled;
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        toggle();
    }

    public void onEnable() {}

    public void onDisable() {}

    public void onSettingChanged(Setting setting) {}

    public String getName() {
        return name;
    }

    public Category getCategory() {
        return category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public int getKeybind() {
        return keybind;
    }

    public void setKeybind(int keybind) {
        this.keybind = keybind;
    }

    protected Setting addSetting(Setting setting) {
        settings.add(setting);
        return setting;
    }

    public java.util.List<Setting> getSettings() {
        return settings;
    }

    public Setting getSetting(String name) {
        for (Setting s : settings) {
            if (s.getName().equalsIgnoreCase(name)) return s;
        }
        return null;
    }
}
