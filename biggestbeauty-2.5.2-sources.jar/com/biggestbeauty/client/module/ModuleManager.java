package com.biggestbeauty.client.module;

import com.biggestbeauty.client.module.impl.cosmetic.ArrowTrailModule;
import com.biggestbeauty.client.module.impl.cosmetic.DamageIndicatorModule;
import com.biggestbeauty.client.module.impl.cosmetic.HitParticlesModule;
import com.biggestbeauty.client.module.impl.cosmetic.KillEffectModule;
import com.biggestbeauty.client.module.impl.cosmetic.LevelUpEffectModule;
import com.biggestbeauty.client.module.impl.cosmetic.ParticleTrailModule;
import com.biggestbeauty.client.module.impl.hud.ArmorPercentHud;
import com.biggestbeauty.client.module.impl.hud.ArmorStatusHud;
import com.biggestbeauty.client.module.impl.hud.ArrayListHud;
import com.biggestbeauty.client.module.impl.hud.CPSCounter;
import com.biggestbeauty.client.module.impl.hud.ClockHud;
import com.biggestbeauty.client.module.impl.hud.ComboHud;
import com.biggestbeauty.client.module.impl.hud.CoordinatesHud;
import com.biggestbeauty.client.module.impl.hud.DifficultyHud;
import com.biggestbeauty.client.module.impl.hud.DimensionHud;
import com.biggestbeauty.client.module.impl.hud.DirectionHud;
import com.biggestbeauty.client.module.impl.hud.DurabilityWarningHud;
import com.biggestbeauty.client.module.impl.hud.FpsPingHud;
import com.biggestbeauty.client.module.impl.hud.HungerWarningModule;
import com.biggestbeauty.client.module.impl.hud.KeystrokesHud;
import com.biggestbeauty.client.module.impl.hud.LowHealthWarningModule;
import com.biggestbeauty.client.module.impl.hud.MobCounterHud;
import com.biggestbeauty.client.module.impl.hud.MoonPhaseHud;
import com.biggestbeauty.client.module.impl.hud.PingGraphHud;
import com.biggestbeauty.client.module.impl.hud.PlayerCounterHud;
import com.biggestbeauty.client.module.impl.hud.PotionTimersHud;
import com.biggestbeauty.client.module.impl.hud.SessionTimerHud;
import com.biggestbeauty.client.module.impl.hud.TargetInfoHud;
import com.biggestbeauty.client.module.impl.hud.TimeOfDayHud;
import com.biggestbeauty.client.module.impl.hud.TntTimerModule;
import com.biggestbeauty.client.module.impl.hud.VelocityHud;
import com.biggestbeauty.client.module.impl.hud.WeatherHud;
import com.biggestbeauty.client.module.impl.hud.XpHud;
import com.biggestbeauty.client.module.impl.media.ScreenRecorderModule;
import com.biggestbeauty.client.module.impl.misc.AntiAfkModule;
import com.biggestbeauty.client.module.impl.misc.AutoRespawnModule;
import com.biggestbeauty.client.module.impl.misc.AutoSprintModule;
import com.biggestbeauty.client.module.impl.misc.ChatTimestampsModule;
import com.biggestbeauty.client.module.impl.misc.NotificationsModule;
import com.biggestbeauty.client.module.impl.misc.QuickChatModule;
import com.biggestbeauty.client.module.impl.misc.RainbowChatModule;
import com.biggestbeauty.client.module.impl.performance.FpsOptimizerModule;
import com.biggestbeauty.client.module.impl.performance.NetOptimizerModule;
import com.biggestbeauty.client.module.impl.render.CustomCrosshairModule;
import com.biggestbeauty.client.module.impl.render.DroppedItemHighlightModule;
import com.biggestbeauty.client.module.impl.render.FullbrightModule;
import com.biggestbeauty.client.module.impl.render.MotionBlurModule;
import com.biggestbeauty.client.module.impl.render.NoFireModule;
import com.biggestbeauty.client.module.impl.render.NoHelmetOverlayModule;
import com.biggestbeauty.client.module.impl.render.NoHurtCamModule;
import com.biggestbeauty.client.module.impl.render.NoPortalOverlayModule;
import com.biggestbeauty.client.module.impl.render.NoViewBobbingModule;
import com.biggestbeauty.client.module.impl.render.ZoomModule;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public void registerDefaults() {
        // HUD
        register(new CPSCounter(Keyboard.KEY_NONE, true));
        register(new KeystrokesHud(Keyboard.KEY_NONE, true));
        register(new ArrayListHud(Keyboard.KEY_NONE, false));
        register(new CoordinatesHud(Keyboard.KEY_NONE, false));
        register(new ArmorStatusHud(Keyboard.KEY_NONE, false));
        register(new PotionTimersHud(Keyboard.KEY_NONE, false));
        register(new FpsPingHud(Keyboard.KEY_NONE, false));
        register(new PingGraphHud(Keyboard.KEY_NONE, false));
        register(new TargetInfoHud(Keyboard.KEY_NONE, false));
        register(new ComboHud(Keyboard.KEY_NONE, false));
        register(new SessionTimerHud(Keyboard.KEY_NONE, false));
        register(new TntTimerModule(Keyboard.KEY_NONE, false));
        register(new LowHealthWarningModule(Keyboard.KEY_NONE, false));
        register(new DirectionHud(Keyboard.KEY_NONE, false));
        register(new ClockHud(Keyboard.KEY_NONE, false));
        register(new ArmorPercentHud(Keyboard.KEY_NONE, false));
        register(new XpHud(Keyboard.KEY_NONE, false));
        register(new DurabilityWarningHud(Keyboard.KEY_NONE, false));
        register(new MobCounterHud(Keyboard.KEY_NONE, false));
        register(new PlayerCounterHud(Keyboard.KEY_NONE, false));
        register(new VelocityHud(Keyboard.KEY_NONE, false));
        register(new HungerWarningModule(Keyboard.KEY_NONE, false));
        register(new DimensionHud(Keyboard.KEY_NONE, false));
        register(new DifficultyHud(Keyboard.KEY_NONE, false));
        register(new TimeOfDayHud(Keyboard.KEY_NONE, false));
        register(new MoonPhaseHud(Keyboard.KEY_NONE, false));
        register(new WeatherHud(Keyboard.KEY_NONE, false));

        // Render
        register(new FullbrightModule(Keyboard.KEY_NONE, false));
        register(new ZoomModule(Keyboard.KEY_C));
        register(new CustomCrosshairModule(Keyboard.KEY_NONE, false));
        register(new NoViewBobbingModule(Keyboard.KEY_NONE, false));
        register(new NoFireModule(Keyboard.KEY_NONE, false));
        register(new NoHurtCamModule(Keyboard.KEY_NONE, false));
        register(new DroppedItemHighlightModule(Keyboard.KEY_NONE, false));
        register(new MotionBlurModule(Keyboard.KEY_NONE, false));
        register(new NoHelmetOverlayModule(Keyboard.KEY_NONE, false));
        register(new NoPortalOverlayModule(Keyboard.KEY_NONE, false));

        // Performance
        register(new FpsOptimizerModule(Keyboard.KEY_NONE, false));
        register(new NetOptimizerModule(Keyboard.KEY_NONE, false));

        // Cosmetic
        register(new HitParticlesModule(Keyboard.KEY_NONE, false));
        register(new KillEffectModule(Keyboard.KEY_NONE, false));
        register(new ParticleTrailModule(Keyboard.KEY_NONE, false));
        register(new DamageIndicatorModule(Keyboard.KEY_NONE, false));
        register(new ArrowTrailModule(Keyboard.KEY_NONE, false));
        register(new LevelUpEffectModule(Keyboard.KEY_NONE, false));

        // Media
        register(new ScreenRecorderModule(Keyboard.KEY_NONE));

        // Misc
        register(new QuickChatModule(Keyboard.KEY_NONE));
        register(new AutoSprintModule(Keyboard.KEY_NONE, false));
        register(new ChatTimestampsModule(Keyboard.KEY_NONE, false));
        register(new NotificationsModule(Keyboard.KEY_NONE, true));
        register(new AntiAfkModule(Keyboard.KEY_NONE, false));
        register(new AutoRespawnModule(Keyboard.KEY_NONE, false));
        register(new RainbowChatModule(Keyboard.KEY_NONE, false));
    }

    public void register(Module module) {
        modules.add(module);
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getModulesByCategory(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) result.add(m);
        }
        return result;
    }

    public List<HudModule> getHudModules() {
        List<HudModule> result = new ArrayList<>();
        for (Module m : modules) {
            if (m instanceof HudModule) result.add((HudModule) m);
        }
        return result;
    }

    public Module getModuleByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) return m;
        }
        return null;
    }

    public <T extends Module> T getModule(Class<T> clazz) {
        for (Module m : modules) {
            if (clazz.isInstance(m)) return clazz.cast(m);
        }
        return null;
    }

    public void handleKeybind(int key) {
        if (key == Keyboard.KEY_NONE) return;
        for (Module m : modules) {
            if (m instanceof ZoomModule) continue;
            if (m.getKeybind() == key) {
                m.toggle();
                notifyToggle(m);
            }
        }
    }

    public void notifyToggle(Module m) {
        Module notif = getModuleByName("Notifications");
        if (notif != null && notif.isEnabled()) {
            com.biggestbeauty.client.util.ToastQueue.push(m.getName() + (m.isEnabled() ? " enabled" : " disabled"));
        }
    }
}
