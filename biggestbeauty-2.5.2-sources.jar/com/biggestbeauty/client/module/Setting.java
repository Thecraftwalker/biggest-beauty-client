package com.biggestbeauty.client.module;

public class Setting {

    public enum Type { BOOLEAN, SLIDER, TEXT }

    private final String name;
    private final Type type;

    private boolean boolValue;

    private float sliderValue;
    private float min;
    private float max;
    private boolean wholeNumbers;

    private String textValue;

    private Setting(String name, Type type) {
        this.name = name;
        this.type = type;
    }

    public static Setting bool(String name, boolean defaultValue) {
        Setting s = new Setting(name, Type.BOOLEAN);
        s.boolValue = defaultValue;
        return s;
    }

    public static Setting slider(String name, float defaultValue, float min, float max, boolean wholeNumbers) {
        Setting s = new Setting(name, Type.SLIDER);
        s.sliderValue = defaultValue;
        s.min = min;
        s.max = max;
        s.wholeNumbers = wholeNumbers;
        return s;
    }

    public static Setting text(String name, String defaultValue) {
        Setting s = new Setting(name, Type.TEXT);
        s.textValue = defaultValue;
        return s;
    }

    public String getName() {
        return name;
    }

    public Type getType() {
        return type;
    }

    public boolean getBool() {
        return boolValue;
    }

    public void setBool(boolean value) {
        this.boolValue = value;
    }

    public void toggleBool() {
        this.boolValue = !this.boolValue;
    }

    public float getSlider() {
        return sliderValue;
    }

    public float getMin() {
        return min;
    }

    public float getMax() {
        return max;
    }

    public boolean isWholeNumbers() {
        return wholeNumbers;
    }

    public void setSlider(float value) {
        if (value < min) value = min;
        if (value > max) value = max;
        this.sliderValue = wholeNumbers ? Math.round(value) : value;
    }

    public void setSliderFraction(float fraction) {
        if (fraction < 0) fraction = 0;
        if (fraction > 1) fraction = 1;
        setSlider(min + fraction * (max - min));
    }

    public float getSliderFraction() {
        return (sliderValue - min) / (max - min);
    }

    public String getText() {
        return textValue;
    }

    public void setText(String value) {
        this.textValue = value;
    }
}
