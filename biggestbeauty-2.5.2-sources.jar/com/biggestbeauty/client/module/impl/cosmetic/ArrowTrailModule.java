package com.biggestbeauty.client.module.impl.cosmetic;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.EnumParticleTypes;

import java.util.List;

public class ArrowTrailModule extends Module {

    public ArrowTrailModule(int keybind, boolean enabledByDefault) {
        super("Arrow Trail", Category.COSMETIC, keybind, enabledByDefault);
    }

    public void onClientTick() {
        if (!isEnabled() || mc.field_71439_g == null || mc.field_71441_e == null) return;

        AxisAlignedBB box = mc.field_71439_g.func_174813_aQ().func_72314_b(48, 48, 48);
        List<EntityArrow> arrows = mc.field_71441_e.func_72872_a(EntityArrow.class, box);
        for (EntityArrow arrow : arrows) {
            mc.field_71441_e.func_175688_a(EnumParticleTypes.CRIT, arrow.field_70165_t, arrow.field_70163_u, arrow.field_70161_v, 0, 0, 0);
        }
    }
}
