package com.biggestbeauty.client.module.impl.cosmetic;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;

import java.util.ArrayList;
import java.util.List;

public class DamageIndicatorModule extends Module {

    public static class Indicator {
        public final int entityId;
        public final float amount;
        public final long createdAt;

        public Indicator(int entityId, float amount) {
            this.entityId = entityId;
            this.amount = amount;
            this.createdAt = System.currentTimeMillis();
        }
    }

    private final List<Indicator> indicators = new ArrayList<>();

    public DamageIndicatorModule(int keybind, boolean enabledByDefault) {
        super("Damage Indicators", Category.COSMETIC, keybind, enabledByDefault);
        addSetting(Setting.text("Hit Colour", "F25C5C"));
    }

    public void addIndicator(int entityId, float amount) {
        indicators.add(new Indicator(entityId, amount));
    }

    public List<Indicator> getActive() {
        long now = System.currentTimeMillis();
        indicators.removeIf(i -> now - i.createdAt > 800);
        return indicators;
    }

    public int getColor() {
        Setting colorSetting = getSetting("Hit Colour");
        String hex = colorSetting != null ? colorSetting.getText() : null;
        if (hex == null) return 0xFFF25C5C;

        hex = hex.trim();
        if (hex.startsWith("#")) hex = hex.substring(1);

        try {
            int rgb = Integer.parseInt(hex, 16) & 0xFFFFFF;
            return 0xFF000000 | rgb;
        } catch (NumberFormatException e) {
            return 0xFFF25C5C;
        }
    }
}
