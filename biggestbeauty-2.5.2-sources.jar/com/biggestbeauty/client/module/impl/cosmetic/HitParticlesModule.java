package com.biggestbeauty.client.module.impl.cosmetic;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumParticleTypes;

public class HitParticlesModule extends Module {

    public HitParticlesModule(int keybind, boolean enabledByDefault) {
        super("Hit Particles", Category.COSMETIC, keybind, enabledByDefault);
        addSetting(Setting.slider("Amount", 8, 1, 20, true));
    }

    public void spawn(Entity target) {
        if (mc.field_71441_e == null) return;
        Setting amount = getSetting("Amount");
        int count = amount != null ? Math.round(amount.getSlider()) : 8;
        for (int i = 0; i < count; i++) {
            double ox = (mc.field_71441_e.field_73012_v.nextDouble() - 0.5) * target.field_70130_N;
            double oy = mc.field_71441_e.field_73012_v.nextDouble() * target.field_70131_O;
            double oz = (mc.field_71441_e.field_73012_v.nextDouble() - 0.5) * target.field_70130_N;
            mc.field_71441_e.func_175688_a(
                    EnumParticleTypes.CRIT_MAGIC,
                    target.field_70165_t + ox, target.field_70163_u + oy, target.field_70161_v + oz,
                    0.0, 0.1, 0.0
            );
        }
    }
}
