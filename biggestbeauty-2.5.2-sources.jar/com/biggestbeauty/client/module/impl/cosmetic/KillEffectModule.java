package com.biggestbeauty.client.module.impl.cosmetic;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumParticleTypes;

public class KillEffectModule extends Module {

    public KillEffectModule(int keybind, boolean enabledByDefault) {
        super("Kill Effect", Category.COSMETIC, keybind, enabledByDefault);
        addSetting(Setting.slider("Amount", 30, 10, 60, true));
    }

    public void spawn(Entity target) {
        if (mc.field_71441_e == null) return;
        Setting amount = getSetting("Amount");
        int count = amount != null ? Math.round(amount.getSlider()) : 30;
        for (int i = 0; i < count; i++) {
            double ox = (mc.field_71441_e.field_73012_v.nextDouble() - 0.5) * 1.5;
            double oy = mc.field_71441_e.field_73012_v.nextDouble() * 1.5;
            double oz = (mc.field_71441_e.field_73012_v.nextDouble() - 0.5) * 1.5;
            mc.field_71441_e.func_175688_a(
                    EnumParticleTypes.SPELL_WITCH,
                    target.field_70165_t + ox, target.field_70163_u + oy, target.field_70161_v + oz,
                    0.0, 0.15, 0.0
            );
        }
    }
}
