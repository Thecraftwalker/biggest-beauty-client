package com.biggestbeauty.client.module.impl.cosmetic;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import net.minecraft.util.EnumParticleTypes;

public class LevelUpEffectModule extends Module {

    private int lastLevel = -1;

    public LevelUpEffectModule(int keybind, boolean enabledByDefault) {
        super("Level Up Effect", Category.COSMETIC, keybind, enabledByDefault);
    }

    public void onClientTick() {
        if (!isEnabled() || mc.field_71439_g == null || mc.field_71441_e == null) return;

        int currentLevel = mc.field_71439_g.field_71068_ca;
        if (lastLevel == -1) {
            lastLevel = currentLevel;
            return;
        }

        if (currentLevel > lastLevel) {
            for (int i = 0; i < 20; i++) {
                double ox = (mc.field_71441_e.field_73012_v.nextDouble() - 0.5) * 1.2;
                double oy = mc.field_71441_e.field_73012_v.nextDouble() * 1.8;
                double oz = (mc.field_71441_e.field_73012_v.nextDouble() - 0.5) * 1.2;
                mc.field_71441_e.func_175688_a(EnumParticleTypes.VILLAGER_HAPPY,
                        mc.field_71439_g.field_70165_t + ox, mc.field_71439_g.field_70163_u + oy, mc.field_71439_g.field_70161_v + oz,
                        0, 0.1, 0);
            }
        }
        lastLevel = currentLevel;
    }
}
