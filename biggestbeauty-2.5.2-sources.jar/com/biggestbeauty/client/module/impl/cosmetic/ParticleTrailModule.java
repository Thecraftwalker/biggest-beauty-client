package com.biggestbeauty.client.module.impl.cosmetic;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;
import net.minecraft.util.EnumParticleTypes;

public class ParticleTrailModule extends Module {

    private int tickCounter = 0;

    public ParticleTrailModule(int keybind, boolean enabledByDefault) {
        super("Particle Trail", Category.COSMETIC, keybind, enabledByDefault);
        addSetting(Setting.slider("Density", 2, 1, 5, true));
    }

    public void onClientTick() {
        if (!isEnabled() || mc.field_71439_g == null || mc.field_71441_e == null) return;
        tickCounter++;

        Setting density = getSetting("Density");
        int everyNTicks = density != null ? Math.max(1, 6 - Math.round(density.getSlider())) : 2;
        if (tickCounter % everyNTicks != 0) return;

        mc.field_71441_e.func_175688_a(
                EnumParticleTypes.SPELL_MOB,
                mc.field_71439_g.field_70165_t + (mc.field_71441_e.field_73012_v.nextDouble() - 0.5) * 0.4,
                mc.field_71439_g.field_70163_u + 0.1,
                mc.field_71439_g.field_70161_v + (mc.field_71441_e.field_73012_v.nextDouble() - 0.5) * 0.4,
                0.9, 0.5, 0.9
        );
    }
}
