package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.item.ItemStack;

public class ArmorPercentHud extends HudModule {

    public ArmorPercentHud(int keybind, boolean enabledByDefault) {
        super("Armor %", Category.HUD, keybind, enabledByDefault, 0.14f, 0.22f);
    }

    private int averagePercent() {
        if (mc.field_71439_g == null) return 100;
        int totalMax = 0;
        int totalRemaining = 0;
        for (int slot = 0; slot < 4; slot++) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70440_f(slot);
            if (stack == null) continue;
            int max = stack.func_77958_k();
            if (max <= 0) continue;
            totalMax += max;
            totalRemaining += (max - stack.func_77952_i());
        }
        if (totalMax == 0) return 0;
        return totalRemaining * 100 / totalMax;
    }

    private String text() {
        return "Armor: " + averagePercent() + "%";
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        int pct = edit ? 80 : averagePercent();
        int color = pct > 50 ? 0xFF8CF28C : (pct > 20 ? 0xFFF7D774 : 0xFFF25C5C);
        RenderUtil.drawShadowedString(text(), getX(sr), getY(sr), color);
    }
}
