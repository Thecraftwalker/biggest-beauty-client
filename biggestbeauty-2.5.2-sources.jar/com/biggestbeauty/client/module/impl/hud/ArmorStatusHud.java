package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.item.ItemStack;

/**
 * Shows durability % of each worn armor piece as text — purely reads your own
 * inventory, which is already fully visible to you in the inventory screen.
 *
 * NOTE: does not import net.minecraft.inventory.EntityEquipmentSlot — that
 * class doesn't exist in 1.8.9 (it's a 1.9+ addition). Armor slots here are
 * addressed by plain int (0-3) via InventoryPlayer.armorItemInSlot(int),
 * which is the correct 1.8.9 API and the only armor-slot method this file uses.
 */
public class ArmorStatusHud extends HudModule {

    private static final String[] LABELS = {"Helmet", "Chest", "Legs", "Boots"};

    public ArmorStatusHud(int keybind, boolean enabledByDefault) {
        super("Armor Status", Category.HUD, keybind, enabledByDefault, 0.14f, 0.06f);
    }

    @Override
    public int getWidth() {
        return 90;
    }

    @Override
    public int getHeight() {
        return 40;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) {
            drawEditBox(sr);
        }
        int x = getX(sr);
        int y = getY(sr);

        if (mc.field_71439_g == null) return;

        ItemStack[] armor = {
                mc.field_71439_g.field_71071_by.func_70440_f(3),
                mc.field_71439_g.field_71071_by.func_70440_f(2),
                mc.field_71439_g.field_71071_by.func_70440_f(1),
                mc.field_71439_g.field_71071_by.func_70440_f(0)
        };

        for (int i = 0; i < armor.length; i++) {
            ItemStack stack = armor[i];
            String line;
            int color;
            if (stack == null) {
                line = LABELS[i] + ": -";
                color = 0xFF777777;
            } else {
                int max = stack.func_77958_k();
                int dur = max - stack.func_77952_i();
                int pct = max > 0 ? (dur * 100 / max) : 100;
                line = LABELS[i] + ": " + pct + "%";
                color = pct > 50 ? 0xFF8CF28C : (pct > 20 ? 0xFFF7D774 : 0xFFF25C5C);
            }
            RenderUtil.drawShadowedString(line, x, y + i * 10, color);
        }
    }
}
