package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.BiggestBeautyClient;
import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class ArrayListHud extends HudModule {

    public ArrayListHud(int keybind, boolean enabledByDefault) {
        super("Array List", Category.HUD, keybind, enabledByDefault, 0.98f, 0.14f);
    }

    @Override
    public int getWidth() {
        int max = 60;
        for (Module m : BiggestBeautyClient.moduleManager.getModules()) {
            if (m == this) continue;
            if (!m.isEnabled()) continue;
            max = Math.max(max, mc.field_71466_p.func_78256_a(m.getName()));
        }
        return max;
    }

    @Override
    public int getHeight() {
        int count = 0;
        for (Module m : BiggestBeautyClient.moduleManager.getModules()) {
            if (m != this && m.isEnabled()) count++;
        }
        return Math.max(count, 1) * 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        int x = getX(sr) + getWidth();
        int y = getY(sr);

        if (edit) {
            drawEditBox(sr);
            RenderUtil.drawStringRightAligned("Array List", x, y, 0xFFFFFFFF);
            return;
        }

        for (Module module : BiggestBeautyClient.moduleManager.getModules()) {
            if (!module.isEnabled() || module == this) continue;
            RenderUtil.drawStringRightAligned(module.getName(), x, y, 0xFFFFFFFF);
            y += 10;
        }
    }
}
