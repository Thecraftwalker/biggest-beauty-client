package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Tracks left/right click counts per second using Forge's MouseEvent, which
 * fires once per real button state change at full input resolution (unlike
 * polling Mouse.isButtonDown() from a once-per-tick event, which misses fast
 * clicks and caps the reading well below real clicking speed).
 */
public class CPSCounter extends HudModule {

    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();

    public CPSCounter(int keybind, boolean enabledByDefault) {
        super("CPS Counter", Category.HUD, keybind, enabledByDefault, 0.98f, 0.02f);
    }

    public void onLeftClick() {
        leftClicks.addLast(System.currentTimeMillis());
    }

    public void onRightClick() {
        rightClicks.addLast(System.currentTimeMillis());
    }

    private int countAndPrune(Deque<Long> deque) {
        long now = System.currentTimeMillis();
        while (!deque.isEmpty() && now - deque.peekFirst() > 1000) {
            deque.pollFirst();
        }
        return deque.size();
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(getPreviewText());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    private String getPreviewText() {
        return "CPS: 12 | 8";
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        int leftCps = countAndPrune(leftClicks);
        int rightCps = countAndPrune(rightClicks);

        String text = edit ? getPreviewText() : ("CPS: " + leftCps + " | " + rightCps);
        int x = getX(sr) + getWidth();
        int y = getY(sr);
        if (edit) drawEditBox(sr);
        RenderUtil.drawStringRightAligned(text, x, y, 0xFFF2A6D6);
    }
}
