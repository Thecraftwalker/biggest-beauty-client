package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ClockHud extends HudModule {

    private final SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");

    public ClockHud(int keybind, boolean enabledByDefault) {
        super("Clock", Category.HUD, keybind, enabledByDefault, 0.98f, 0.26f);
    }

    private String text() {
        return format.format(new Date());
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawStringRightAligned(text(), getX(sr) + getWidth(), getY(sr), 0xFFCCCCCC);
    }
}
