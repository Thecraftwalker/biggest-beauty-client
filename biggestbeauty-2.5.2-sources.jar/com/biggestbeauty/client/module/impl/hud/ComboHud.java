package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;

public class ComboHud extends HudModule {

    private int combo = 0;
    private int lastTargetId = -1;
    private long lastHitTime = 0;
    private static final long TIMEOUT_MS = 2500;

    public ComboHud(int keybind, boolean enabledByDefault) {
        super("Combo", Category.HUD, keybind, enabledByDefault, 0.5f, 0.60f);
    }

    public void onHit(Entity target) {
        long now = System.currentTimeMillis();
        int id = target.func_145782_y();
        if (id == lastTargetId && now - lastHitTime < TIMEOUT_MS) {
            combo++;
        } else {
            combo = 1;
        }
        lastTargetId = id;
        lastHitTime = now;
    }

    private boolean isActive() {
        return combo > 1 && System.currentTimeMillis() - lastHitTime < TIMEOUT_MS;
    }

    @Override
    public int getWidth() {
        return 60;
    }

    @Override
    public int getHeight() {
        return 12;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (!edit && !isActive()) return;

        String text = edit ? "Combo: 5x" : ("Combo: " + combo + "x");
        int width = mc.field_71466_p.func_78256_a(text);
        int x = getX(sr) + getWidth() / 2 - width / 2;
        int y = getY(sr);
        if (edit) drawEditBox(sr);
        RenderUtil.drawShadowedString(text, x, y, 0xFFF25C5C);
    }
}
