package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class CoordinatesHud extends HudModule {

    public CoordinatesHud(int keybind, boolean enabledByDefault) {
        super("Coordinates", Category.HUD, keybind, enabledByDefault, 0.14f, 0.02f);
    }

    private String text() {
        if (mc.field_71439_g == null) return "XYZ: 0, 0, 0";
        return String.format("XYZ: %.0f, %.0f, %.0f",
                mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawShadowedString(text(), getX(sr), getY(sr), 0xFFFFFFFF);
    }
}
