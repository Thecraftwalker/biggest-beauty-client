package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class DifficultyHud extends HudModule {

    public DifficultyHud(int keybind, boolean enabledByDefault) {
        super("Difficulty", Category.HUD, keybind, enabledByDefault, 0.98f, 0.34f);
    }

    private String text() {
        try {
            if (mc.field_71441_e == null) return "Normal";
            return mc.field_71441_e.func_175659_aa().name();
        } catch (Exception e) {
            return "Unknown";
        }
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawStringRightAligned(text(), getX(sr) + getWidth(), getY(sr), 0xFFAAAAAA);
    }
}
