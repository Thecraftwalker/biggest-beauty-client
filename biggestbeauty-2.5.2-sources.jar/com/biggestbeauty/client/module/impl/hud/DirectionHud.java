package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class DirectionHud extends HudModule {

    private static final String[] DIRS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};

    public DirectionHud(int keybind, boolean enabledByDefault) {
        super("Direction", Category.HUD, keybind, enabledByDefault, 0.5f, 0.03f);
    }

    private String text() {
        if (mc.field_71439_g == null) return "S 0°";
        float yaw = mc.field_71439_g.field_70177_z % 360;
        if (yaw < 0) yaw += 360;
        int index = Math.round(yaw / 45f) % 8;
        return DIRS[index] + " " + Math.round(yaw) + "°";
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawShadowedString(text(), getX(sr), getY(sr), 0xFFFFFFFF);
    }
}
