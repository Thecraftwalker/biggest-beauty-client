package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.item.ItemStack;

public class DurabilityWarningHud extends HudModule {

    public DurabilityWarningHud(int keybind, boolean enabledByDefault) {
        super("Durability Warning", Category.HUD, keybind, enabledByDefault, 0.5f, 0.85f);
    }

    private ItemStack heldItem() {
        return mc.field_71439_g != null ? mc.field_71439_g.func_70694_bm() : null;
    }

    private boolean shouldWarn(ItemStack stack) {
        if (stack == null || stack.func_77958_k() <= 0) return false;
        int remaining = stack.func_77958_k() - stack.func_77952_i();
        return remaining <= Math.max(5, stack.func_77958_k() / 10);
    }

    @Override
    public int getWidth() {
        return 140;
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        String text = "Item about to break!";
        if (!edit) {
            ItemStack stack = heldItem();
            if (!shouldWarn(stack)) return;
        }
        int width = mc.field_71466_p.func_78256_a(text);
        int x = getX(sr) + getWidth() / 2 - width / 2;
        if (edit) drawEditBox(sr);
        RenderUtil.drawShadowedString(text, x, getY(sr), 0xFFF25C5C);
    }
}
