package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;

public class FpsPingHud extends HudModule {

    public FpsPingHud(int keybind, boolean enabledByDefault) {
        super("FPS & Ping", Category.HUD, keybind, enabledByDefault, 0.02f, 0.10f);
    }

    private String text() {
        int fps = net.minecraft.client.Minecraft.func_175610_ah();
        int ping = getPing();
        return fps + " fps | " + ping + "ms";
    }

    private int getPing() {
        try {
            if (mc.field_71439_g == null || mc.func_147114_u() == null) return 0;
            NetHandlerPlayClient handler = mc.func_147114_u();
            NetworkPlayerInfo info = handler.func_175102_a(mc.field_71439_g.func_110124_au());
            return info != null ? info.func_178853_c() : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawShadowedString(text(), getX(sr), getY(sr), 0xFFF7D774);
    }
}
