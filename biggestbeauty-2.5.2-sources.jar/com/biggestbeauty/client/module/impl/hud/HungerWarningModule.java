package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class HungerWarningModule extends Module {

    public HungerWarningModule(int keybind, boolean enabledByDefault) {
        super("Hunger Warning", Category.HUD, keybind, enabledByDefault);
        addSetting(Setting.slider("Threshold (hunger)", 6, 1, 19, true));
    }

    public void render(ScaledResolution sr) {
        if (mc.field_71439_g == null) return;

        Setting threshold = getSetting("Threshold (hunger)");
        int thresholdFood = threshold != null ? Math.round(threshold.getSlider()) : 6;
        int food = mc.field_71439_g.func_71024_bL().func_75116_a();
        if (food > thresholdFood) return;

        int w = sr.func_78326_a();
        int h = sr.func_78328_b();
        int edge = 24;
        int color = 0x50D4A93B;

        RenderUtil.drawRect(0, h - edge, w, h, color);
    }
}
