package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class KeystrokesHud extends HudModule {

    private static final int KEY_SIZE = 20;
    private static final int GAP = 2;
    private static final int WIDTH = KEY_SIZE * 3 + GAP * 2;
    private static final int HEIGHT = KEY_SIZE * 3 + GAP * 2;

    public KeystrokesHud(int keybind, boolean enabledByDefault) {
        super("Keystrokes", Category.HUD, keybind, enabledByDefault, 0.02f + (float) WIDTH / 1000f, 0.85f);
    }

    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        int baseX = getX(sr);
        int baseY = getY(sr);

        if (edit) drawEditBox(sr);

        boolean w = mc.field_71474_y.field_74351_w.func_151470_d();
        boolean a = mc.field_71474_y.field_74370_x.func_151470_d();
        boolean s = mc.field_71474_y.field_74368_y.func_151470_d();
        boolean d = mc.field_71474_y.field_74366_z.func_151470_d();
        boolean space = mc.field_71474_y.field_74314_A.func_151470_d();

        drawKey("W", baseX + KEY_SIZE + GAP, baseY, !edit && w);
        drawKey("A", baseX, baseY + KEY_SIZE + GAP, !edit && a);
        drawKey("S", baseX + KEY_SIZE + GAP, baseY + KEY_SIZE + GAP, !edit && s);
        drawKey("D", baseX + (KEY_SIZE + GAP) * 2, baseY + KEY_SIZE + GAP, !edit && d);

        int spaceY = baseY + (KEY_SIZE + GAP) * 2;
        RenderUtil.drawKeyBox("SPACE", baseX, spaceY, WIDTH, KEY_SIZE, !edit && space);
    }

    private void drawKey(String label, int x, int y, boolean pressed) {
        RenderUtil.drawKeyBox(label, x, y, KEY_SIZE, KEY_SIZE, pressed);
    }
}
