package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class LowHealthWarningModule extends Module {

    public LowHealthWarningModule(int keybind, boolean enabledByDefault) {
        super("Low Health Warning", Category.HUD, keybind, enabledByDefault);
        addSetting(Setting.slider("Threshold (hearts)", 6, 1, 19, true));
    }

    public void render(ScaledResolution sr) {
        if (mc.field_71439_g == null) return;

        Setting threshold = getSetting("Threshold (hearts)");
        float thresholdHealth = (threshold != null ? threshold.getSlider() : 6) * 1f;
        float health = mc.field_71439_g.func_110143_aJ();
        if (health <= 0 || health > thresholdHealth) return;

        float intensity = 1f - (health / thresholdHealth);
        int alpha = (int) (100 * intensity) + 20;
        int color = (Math.min(255, alpha) << 24) | 0xAA0000;

        int w = sr.func_78326_a();
        int h = sr.func_78328_b();
        int edge = 40;

        RenderUtil.drawRect(0, 0, w, edge, color);
        RenderUtil.drawRect(0, h - edge, w, h, color);
        RenderUtil.drawRect(0, 0, edge, h, color);
        RenderUtil.drawRect(w - edge, 0, w, h, color);
    }
}
