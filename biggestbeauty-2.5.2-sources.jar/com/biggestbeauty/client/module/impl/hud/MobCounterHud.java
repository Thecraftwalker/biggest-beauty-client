package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.util.AxisAlignedBB;

import java.util.List;

public class MobCounterHud extends HudModule {

    public MobCounterHud(int keybind, boolean enabledByDefault) {
        super("Mob Counter", Category.HUD, keybind, enabledByDefault, 0.14f, 0.34f);
    }

    private int count() {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return 0;
        AxisAlignedBB box = mc.field_71439_g.func_174813_aQ().func_72314_b(32, 32, 32);
        List<EntityMob> mobs = mc.field_71441_e.func_72872_a(EntityMob.class, box);
        return mobs.size();
    }

    private String text() {
        return "Mobs nearby: " + (mc.field_71439_g == null ? 0 : count());
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawShadowedString(edit ? "Mobs nearby: 3" : text(), getX(sr), getY(sr), 0xFFF7D774);
    }
}
