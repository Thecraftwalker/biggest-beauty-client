package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class MoonPhaseHud extends HudModule {

    private static final String[] PHASES = {
            "Full Moon", "Waning Gibbous", "Last Quarter", "Waning Crescent",
            "New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous"
    };

    public MoonPhaseHud(int keybind, boolean enabledByDefault) {
        super("Moon Phase", Category.HUD, keybind, enabledByDefault, 0.98f, 0.42f);
    }

    private String text() {
        try {
            if (mc.field_71441_e == null) return PHASES[0];
            int phase = mc.field_71441_e.func_72853_d() % 8;
            return PHASES[phase];
        } catch (Exception e) {
            return "Unknown";
        }
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawStringRightAligned(text(), getX(sr) + getWidth(), getY(sr), 0xFFCCCCCC);
    }
}
