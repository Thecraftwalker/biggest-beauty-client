package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;

import java.util.ArrayDeque;
import java.util.Deque;

public class PingGraphHud extends HudModule {

    private static final int WIDTH = 80;
    private static final int HEIGHT = 30;
    private static final int MAX_SAMPLES = 40;

    private final Deque<Integer> samples = new ArrayDeque<>();
    private int tickCounter = 0;

    public PingGraphHud(int keybind, boolean enabledByDefault) {
        super("Ping Graph", Category.HUD, keybind, enabledByDefault, 0.02f, 0.20f);
    }

    private int getPing() {
        try {
            if (mc.field_71439_g == null || mc.func_147114_u() == null) return 0;
            NetHandlerPlayClient handler = mc.func_147114_u();
            NetworkPlayerInfo info = handler.func_175102_a(mc.field_71439_g.func_110124_au());
            return info != null ? info.func_178853_c() : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    public void onClientTick() {
        tickCounter++;
        if (tickCounter % 10 != 0) return;
        samples.addLast(getPing());
        while (samples.size() > MAX_SAMPLES) samples.pollFirst();
    }

    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT + 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        int x = getX(sr);
        int y = getY(sr);

        if (edit) drawEditBox(sr);

        RenderUtil.drawRect(x, y, x + WIDTH, y + HEIGHT, RenderUtil.THEME_BG);
        RenderUtil.drawOutline(x, y, x + WIDTH, y + HEIGHT, RenderUtil.THEME_ACCENT, 1);

        Integer[] values = edit
                ? new Integer[]{40, 45, 38, 60, 42, 39, 41}
                : samples.toArray(new Integer[0]);

        if (values.length > 1) {
            int max = 1;
            for (int v : values) max = Math.max(max, v);
            max = Math.max(max, 50);

            float step = (float) WIDTH / (MAX_SAMPLES - 1);
            int startIdx = Math.max(0, values.length - MAX_SAMPLES);
            int prevPx = -1, prevPy = -1;
            for (int i = startIdx; i < values.length; i++) {
                int px = x + Math.round((i - startIdx) * step);
                int py = y + HEIGHT - Math.round((values[i] / (float) max) * (HEIGHT - 2)) - 1;
                if (prevPx != -1) {
                    RenderUtil.drawRect(Math.min(prevPx, px), Math.min(prevPy, py),
                            Math.max(prevPx, px) + 1, Math.max(prevPy, py) + 1, RenderUtil.THEME_ACCENT);
                }
                prevPx = px;
                prevPy = py;
            }
        }

        int current = edit ? 41 : (values.length > 0 ? values[values.length - 1] : 0);
        RenderUtil.drawShadowedString(current + "ms", x, y + HEIGHT + 2, 0xFFAAAAAA);
    }
}
