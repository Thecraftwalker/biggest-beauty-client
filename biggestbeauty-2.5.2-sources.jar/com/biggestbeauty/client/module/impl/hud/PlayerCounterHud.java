package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;

import java.util.List;

public class PlayerCounterHud extends HudModule {

    public PlayerCounterHud(int keybind, boolean enabledByDefault) {
        super("Player Counter", Category.HUD, keybind, enabledByDefault, 0.14f, 0.38f);
    }

    private int count() {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return 0;
        AxisAlignedBB box = mc.field_71439_g.func_174813_aQ().func_72314_b(48, 48, 48);
        List<EntityPlayer> players = mc.field_71441_e.func_72872_a(EntityPlayer.class, box);
        int count = 0;
        for (EntityPlayer p : players) {
            if (p != mc.field_71439_g) count++;
        }
        return count;
    }

    private String text() {
        return "Players nearby: " + (mc.field_71439_g == null ? 0 : count());
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawShadowedString(edit ? "Players nearby: 2" : text(), getX(sr), getY(sr), 0xFFF2A6D6);
    }
}
