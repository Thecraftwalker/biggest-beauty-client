package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

import java.util.Collection;

public class PotionTimersHud extends HudModule {

    public PotionTimersHud(int keybind, boolean enabledByDefault) {
        super("Potion Timers", Category.HUD, keybind, enabledByDefault, 0.14f, 0.30f);
    }

    private Collection<PotionEffect> effects() {
        if (mc.field_71439_g == null) return java.util.Collections.emptyList();
        return mc.field_71439_g.func_70651_bq();
    }

    @Override
    public int getWidth() {
        int max = 60;
        for (PotionEffect e : effects()) {
            max = Math.max(max, mc.field_71466_p.func_78256_a(line(e)));
        }
        return max;
    }

    @Override
    public int getHeight() {
        return Math.max(effects().size(), 1) * 10;
    }

    private String line(PotionEffect e) {
        Potion potion = Potion.field_76425_a[e.func_76456_a()];
        String name = potion != null ? net.minecraft.util.StatCollector.func_74838_a(potion.func_76393_a()) : "Effect";
        int seconds = e.func_76459_b() / 20;
        return name + " " + (e.func_76458_c() + 1) + " (" + seconds + "s)";
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        int x = getX(sr);
        int y = getY(sr);
        if (edit) {
            drawEditBox(sr);
            RenderUtil.drawShadowedString("Regeneration 2 (12s)", x, y, 0xFFF2A6D6);
            return;
        }
        for (PotionEffect e : effects()) {
            RenderUtil.drawShadowedString(line(e), x, y, 0xFFF2A6D6);
            y += 10;
        }
    }
}
