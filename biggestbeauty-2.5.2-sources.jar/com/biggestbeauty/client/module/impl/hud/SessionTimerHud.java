package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class SessionTimerHud extends HudModule {

    private long joinTime = System.currentTimeMillis();

    public SessionTimerHud(int keybind, boolean enabledByDefault) {
        super("Session Timer", Category.HUD, keybind, enabledByDefault, 0.14f, 0.10f);
    }

    @Override
    public void onEnable() {
        joinTime = System.currentTimeMillis();
    }

    private String text() {
        long elapsed = (System.currentTimeMillis() - joinTime) / 1000;
        long h = elapsed / 3600;
        long m = (elapsed % 3600) / 60;
        long s = elapsed % 60;
        return String.format("Session: %02d:%02d:%02d", h, m, s);
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawShadowedString(text(), getX(sr), getY(sr), 0xFFAAAAAA);
    }
}
