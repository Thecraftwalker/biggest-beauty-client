package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MovingObjectPosition;

public class TargetInfoHud extends HudModule {

    public TargetInfoHud(int keybind, boolean enabledByDefault) {
        super("Target Info", Category.HUD, keybind, enabledByDefault, 0.5f, 0.75f);
    }

    private EntityLivingBase getTarget() {
        if (mc.field_71476_x == null || mc.field_71476_x.field_72313_a != MovingObjectPosition.MovingObjectType.ENTITY) {
            return null;
        }
        if (mc.field_71476_x.field_72308_g instanceof EntityLivingBase) {
            return (EntityLivingBase) mc.field_71476_x.field_72308_g;
        }
        return null;
    }

    @Override
    public int getWidth() {
        return 100;
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        int x = getX(sr) + getWidth() / 2;
        int y = getY(sr);

        String text;
        if (edit) {
            text = "Zombie  14.0 / 20.0";
            drawEditBox(sr);
        } else {
            EntityLivingBase target = getTarget();
            if (target == null) return;
            text = target.func_70005_c_() + "  " + String.format("%.1f", target.func_110143_aJ())
                    + " / " + String.format("%.1f", target.func_110138_aP());
        }

        int width = mc.field_71466_p.func_78256_a(text);
        RenderUtil.drawShadowedString(text, x - width / 2, y, 0xFFFFFFFF);
    }
}
