package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class TimeOfDayHud extends HudModule {

    public TimeOfDayHud(int keybind, boolean enabledByDefault) {
        super("World Time", Category.HUD, keybind, enabledByDefault, 0.98f, 0.38f);
    }

    private String text() {
        if (mc.field_71441_e == null) return "00:00";
        long time = mc.field_71441_e.func_72820_D() % 24000;
        long hours = ((time / 1000) + 6) % 24;
        long minutes = (time % 1000) * 60 / 1000;
        return String.format("%02d:%02d", hours, minutes);
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawStringRightAligned(text(), getX(sr) + getWidth(), getY(sr), 0xFFF7D774);
    }
}
