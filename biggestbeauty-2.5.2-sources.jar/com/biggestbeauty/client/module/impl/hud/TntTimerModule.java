package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import net.minecraft.entity.item.EntityTNTPrimed;

/**
 * Shows a countdown (in seconds) floating above every primed TNT entity in
 * render distance. World-space text rendering happens in WorldRenderHandler.
 *
 * FIXED: an earlier version tried to read the fuse value via reflection,
 * guessing at private field names — none matched, so it always showed "?".
 * This version reads only Entity.ticksExisted (a guaranteed-public field on
 * every entity in every MC version) against vanilla's default 80-tick fuse.
 * Tradeoff: a non-default fuse length (command blocks, plugins) won't be
 * reflected accurately, but for normal TNT this is correct and doesn't guess
 * at any unverifiable private field name.
 */
public class TntTimerModule extends Module {

    private static final int VANILLA_DEFAULT_FUSE_TICKS = 80;

    public TntTimerModule(int keybind, boolean enabledByDefault) {
        super("TNT Timer", Category.HUD, keybind, enabledByDefault);
    }

    public String formatFuse(EntityTNTPrimed tnt) {
        int remainingTicks = Math.max(0, VANILLA_DEFAULT_FUSE_TICKS - tnt.field_70173_aa);
        return String.format("%.1fs", remainingTicks / 20f);
    }
}
