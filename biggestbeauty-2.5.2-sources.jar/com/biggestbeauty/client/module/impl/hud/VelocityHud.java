package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class VelocityHud extends HudModule {

    private double lastX, lastY, lastZ;
    private boolean initialized = false;
    private double blocksPerSecond = 0;
    private int tickCounter = 0;

    public VelocityHud(int keybind, boolean enabledByDefault) {
        super("Speed", Category.HUD, keybind, enabledByDefault, 0.14f, 0.42f);
    }

    public void onClientTick() {
        if (mc.field_71439_g == null) return;
        if (!initialized) {
            lastX = mc.field_71439_g.field_70165_t;
            lastY = mc.field_71439_g.field_70163_u;
            lastZ = mc.field_71439_g.field_70161_v;
            initialized = true;
            return;
        }
        tickCounter++;
        if (tickCounter >= 20) {
            tickCounter = 0;
            double dx = mc.field_71439_g.field_70165_t - lastX;
            double dy = mc.field_71439_g.field_70163_u - lastY;
            double dz = mc.field_71439_g.field_70161_v - lastZ;
            blocksPerSecond = Math.sqrt(dx * dx + dy * dy + dz * dz);
            lastX = mc.field_71439_g.field_70165_t;
            lastY = mc.field_71439_g.field_70163_u;
            lastZ = mc.field_71439_g.field_70161_v;
        }
    }

    private String text() {
        return String.format("Speed: %.1f b/s", blocksPerSecond);
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawShadowedString(edit ? "Speed: 4.3 b/s" : text(), getX(sr), getY(sr), 0xFFFFFFFF);
    }
}
