package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class WeatherHud extends HudModule {

    public WeatherHud(int keybind, boolean enabledByDefault) {
        super("Weather", Category.HUD, keybind, enabledByDefault, 0.98f, 0.46f);
    }

    private String text() {
        if (mc.field_71441_e == null) return "Clear";
        if (mc.field_71441_e.func_72911_I()) return "Thunderstorm";
        if (mc.field_71441_e.func_72896_J()) return "Raining";
        return "Clear";
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawStringRightAligned(text(), getX(sr) + getWidth(), getY(sr), 0xFF88AACC);
    }
}
