package com.biggestbeauty.client.module.impl.hud;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class XpHud extends HudModule {

    public XpHud(int keybind, boolean enabledByDefault) {
        super("XP Info", Category.HUD, keybind, enabledByDefault, 0.14f, 0.26f);
    }

    private String text() {
        if (mc.field_71439_g == null) return "Lvl 0 (0%)";
        int level = mc.field_71439_g.field_71068_ca;
        int pct = Math.round(mc.field_71439_g.field_71106_cc * 100);
        return "Lvl " + level + " (" + pct + "%)";
    }

    @Override
    public int getWidth() {
        return mc.field_71466_p.func_78256_a(text());
    }

    @Override
    public int getHeight() {
        return 10;
    }

    @Override
    public void render(ScaledResolution sr, boolean edit) {
        if (edit) drawEditBox(sr);
        RenderUtil.drawShadowedString(text(), getX(sr), getY(sr), 0xFF8CF28C);
    }
}
