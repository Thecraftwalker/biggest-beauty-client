package com.biggestbeauty.client.module.impl.media;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;
import com.biggestbeauty.client.util.media.GameRecorderUtil;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.util.List;

/**
 * Records the Minecraft window (+ optional microphone) to a folder of PNG
 * frames + audio.wav, then opens that folder. Doesn't auto-encode to mp4 —
 * see GameRecorderUtil's javadoc for why (two different approaches to that
 * both failed for different reasons). Combine them yourself with ffmpeg
 * using the command printed to console when you stop recording.
 */
public class ScreenRecorderModule extends Module {

    public ScreenRecorderModule(int keybind) {
        super("Screen Recorder", Category.MEDIA, keybind, false);
        addSetting(Setting.bool("Include Microphone", true));
        addSetting(Setting.slider("FPS", 30, 10, 60, true));
    }

    private File outputDir() {
        return new File(Minecraft.func_71410_x().field_71412_D, "biggestbeauty_recordings");
    }

    @Override
    public void onEnable() {
        Setting mic = getSetting("Include Microphone");
        Setting fps = getSetting("FPS");
        boolean includeAudio = mic == null || mic.getBool();
        int frameRate = fps != null ? Math.round(fps.getSlider()) : 30;

        try {
            GameRecorderUtil.start(includeAudio, frameRate, outputDir());
        } catch (Exception e) {
            System.err.println("[BiggestBeauty] Failed to start recording: " + e.getMessage());
            e.printStackTrace();
            setEnabled(false); // roll back the toggle since nothing actually started
        }
    }

    @Override
    public void onDisable() {
        try {
            List<File> files = GameRecorderUtil.stop();
            for (File f : files) {
                System.out.println("[BiggestBeauty] Recording saved: " + f.getAbsolutePath());
            }
        } catch (Exception e) {
            System.err.println("[BiggestBeauty] Failed to stop recording cleanly: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
