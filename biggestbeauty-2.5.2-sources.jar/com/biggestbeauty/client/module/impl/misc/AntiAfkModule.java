package com.biggestbeauty.client.module.impl.misc;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;

public class AntiAfkModule extends Module {

    private long lastActivity = System.currentTimeMillis();
    private long lastJump = 0;

    public AntiAfkModule(int keybind, boolean enabledByDefault) {
        super("Anti AFK", Category.MISC, keybind, enabledByDefault);
        addSetting(Setting.slider("Idle Minutes", 3, 1, 10, true));
    }

    public void onMouseOrKeyActivity() {
        lastActivity = System.currentTimeMillis();
    }

    public void onClientTick() {
        if (!isEnabled() || mc.thePlayer == null) return;

        Setting idleMinutes = getSetting("Idle Minutes");
        long thresholdMs = (idleMinutes != null ? (long) idleMinutes.getSlider() : 3) * 60_000L;

        long now = System.currentTimeMillis();
        if (now - lastActivity < thresholdMs) return;
        if (now - lastJump < 5000) return;

        mc.thePlayer.jump();
        lastJump = now;
    }
}
