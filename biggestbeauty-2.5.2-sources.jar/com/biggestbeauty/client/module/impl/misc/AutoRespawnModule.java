package com.biggestbeauty.client.module.impl.misc;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.network.play.client.C16PacketClientStatus;

public class AutoRespawnModule extends Module {

    private boolean respawnedForThisDeath = false;

    public AutoRespawnModule(int keybind, boolean enabledByDefault) {
        super("Auto Respawn", Category.MISC, keybind, enabledByDefault);
    }

    public void onClientTick() {
        if (!isEnabled()) {
            respawnedForThisDeath = false;
            return;
        }

        boolean onDeathScreen = mc.field_71462_r instanceof GuiGameOver;
        if (!onDeathScreen) {
            respawnedForThisDeath = false;
            return;
        }

        if (respawnedForThisDeath) return;
        if (mc.func_147114_u() == null) return;

        try {
            mc.func_147114_u().func_147297_a(new C16PacketClientStatus(C16PacketClientStatus.EnumState.PERFORM_RESPAWN));
            respawnedForThisDeath = true;
        } catch (Exception e) {
            System.err.println("[BiggestBeauty] Auto Respawn failed to send respawn packet: " + e.getMessage());
        }
    }
}
