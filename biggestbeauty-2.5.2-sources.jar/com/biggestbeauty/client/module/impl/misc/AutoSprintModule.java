package com.biggestbeauty.client.module.impl.misc;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;

public class AutoSprintModule extends Module {

    public AutoSprintModule(int keybind, boolean enabledByDefault) {
        super("Auto Sprint", Category.MISC, keybind, enabledByDefault);
    }

    public void onClientTick() {
        if (!isEnabled() || mc.field_71439_g == null) return;
        if (mc.field_71439_g.field_70123_F) return;
        boolean movingForward = mc.field_71474_y.field_74351_w.func_151470_d();
        boolean canSprint = mc.field_71439_g.func_71024_bL().func_75116_a() > 6 || mc.field_71439_g.field_71075_bZ.field_75100_b;
        if (movingForward && canSprint && !mc.field_71439_g.func_70051_ag() && !mc.field_71439_g.func_70093_af()) {
            mc.field_71439_g.func_70031_b(true);
        }
    }
}
