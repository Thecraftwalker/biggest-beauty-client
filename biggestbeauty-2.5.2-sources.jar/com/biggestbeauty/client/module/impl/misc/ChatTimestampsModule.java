package com.biggestbeauty.client.module.impl.misc;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;

public class ChatTimestampsModule extends Module {

    public ChatTimestampsModule(int keybind, boolean enabledByDefault) {
        super("Chat Timestamps", Category.MISC, keybind, enabledByDefault);
    }
}
