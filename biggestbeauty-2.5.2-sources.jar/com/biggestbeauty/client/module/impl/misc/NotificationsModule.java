package com.biggestbeauty.client.module.impl.misc;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;

public class NotificationsModule extends Module {

    public NotificationsModule(int keybind, boolean enabledByDefault) {
        super("Notifications", Category.MISC, keybind, enabledByDefault);
    }
}
