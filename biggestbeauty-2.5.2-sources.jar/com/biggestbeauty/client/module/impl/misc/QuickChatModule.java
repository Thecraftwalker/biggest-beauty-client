package com.biggestbeauty.client.module.impl.misc;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;

public class QuickChatModule extends Module {

    public QuickChatModule(int keybind) {
        super("Quick Chat", Category.MISC, keybind, false);
        addSetting(Setting.text("Message", "gg"));
    }

    public void send() {
        Setting msg = getSetting("Message");
        if (mc.field_71439_g == null || msg == null) return;
        String text = msg.getText();
        if (text == null || text.trim().isEmpty()) return;

        RainbowChatModule rainbow = com.biggestbeauty.client.BiggestBeautyClient.moduleManager.getModule(RainbowChatModule.class);
        if (rainbow != null && rainbow.isEnabled()) {
            text = rainbow.colorize(text);
        }

        mc.field_71439_g.func_71165_d(text);
    }

    @Override
    public void toggle() {
        send();
    }
}
