package com.biggestbeauty.client.module.impl.misc;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;

/**
 * Colorizes messages sent via Quick Chat specifically (see QuickChatModule.send()),
 * not all typed chat — that would need hooking Minecraft's outgoing-chat path,
 * not something verifiable as a safe existing Forge event in 1.8.9.
 */
public class RainbowChatModule extends Module {

    private static final char[] COLORS = {'c', '6', 'e', 'a', 'b', '9', 'd'};
    private int colorIndex = 0;

    public RainbowChatModule(int keybind, boolean enabledByDefault) {
        super("Rainbow Chat", Category.MISC, keybind, enabledByDefault);
    }

    public String colorize(String message) {
        StringBuilder result = new StringBuilder();
        for (char c : message.toCharArray()) {
            result.append('\u00a7').append(COLORS[colorIndex % COLORS.length]);
            result.append(c);
            colorIndex++;
        }
        return result.toString();
    }
}
