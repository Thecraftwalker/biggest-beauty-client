package com.biggestbeauty.client.module.impl.performance;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;
import net.minecraft.client.settings.GameSettings;

public class FpsOptimizerModule extends Module {

    private boolean prevFancyGraphics;
    private boolean prevEnableVsync;
    private int prevAmbientOcclusion;
    private int prevParticleSetting;
    private int prevRenderDistance;
    private int prevMipmapLevels;
    private boolean prevEntityShadows;
    private int prevLimitFramerate;

    public FpsOptimizerModule(int keybind, boolean enabledByDefault) {
        super("FPS Optimizer", Category.PERFORMANCE, keybind, enabledByDefault);
        addSetting(Setting.slider("Render Distance", 8, 2, 16, true));
        addSetting(Setting.slider("Max FPS", 260, 30, 260, true));
    }

    @Override
    public void onEnable() {
        GameSettings s = mc.field_71474_y;

        prevFancyGraphics = s.field_74347_j;
        prevEnableVsync = s.field_74352_v;
        prevAmbientOcclusion = s.field_74348_k;
        prevParticleSetting = s.field_74362_aa;
        prevRenderDistance = s.field_151451_c;
        prevMipmapLevels = s.field_151442_I;
        prevEntityShadows = s.field_181151_V;
        prevLimitFramerate = s.field_74350_i;

        s.field_74347_j = false;
        s.field_74352_v = false;
        s.field_74348_k = 0;
        s.field_74362_aa = 2;
        s.field_151442_I = 0;
        s.field_181151_V = false;
        applyRenderDistance();
        applyMaxFps();

        mc.field_71438_f.func_72712_a();
    }

    @Override
    public void onDisable() {
        GameSettings s = mc.field_71474_y;
        s.field_74347_j = prevFancyGraphics;
        s.field_74352_v = prevEnableVsync;
        s.field_74348_k = prevAmbientOcclusion;
        s.field_74362_aa = prevParticleSetting;
        s.field_151451_c = prevRenderDistance;
        s.field_151442_I = prevMipmapLevels;
        s.field_181151_V = prevEntityShadows;
        s.field_74350_i = prevLimitFramerate;

        mc.field_71438_f.func_72712_a();
    }

    @Override
    public void onSettingChanged(Setting setting) {
        if (!isEnabled()) return;
        if ("Render Distance".equals(setting.getName())) {
            applyRenderDistance();
            mc.field_71438_f.func_72712_a();
        } else if ("Max FPS".equals(setting.getName())) {
            applyMaxFps();
        }
    }

    private void applyRenderDistance() {
        Setting rd = getSetting("Render Distance");
        int value = rd != null ? Math.round(rd.getSlider()) : 8;
        mc.field_71474_y.field_151451_c = value;
    }

    private void applyMaxFps() {
        Setting fps = getSetting("Max FPS");
        int value = fps != null ? Math.round(fps.getSlider()) : 260;
        mc.field_71474_y.field_74350_i = value;
    }
}
