package com.biggestbeauty.client.module.impl.performance;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;

/**
 * A client mod cannot lower real network ping — that's round-trip time over
 * your actual internet connection, nothing running inside Minecraft can
 * shorten it. This module instead watches your measured FPS (once/second,
 * via TickHandler) and adaptively trims render distance + particles when FPS
 * genuinely drops, restoring once it recovers — targets frame-time spikes
 * that feel like lag, not network RTT.
 */
public class NetOptimizerModule extends Module {

    private int prevParticleSetting;
    private int prevRenderDistance;
    private boolean currentlyReduced = false;

    public NetOptimizerModule(int keybind, boolean enabledByDefault) {
        super("Net Optimizer", Category.PERFORMANCE, keybind, enabledByDefault);
        addSetting(Setting.slider("Min FPS Threshold", 30, 10, 60, true));
    }

    @Override
    public void onEnable() {
        prevParticleSetting = mc.field_71474_y.field_74362_aa;
        prevRenderDistance = mc.field_71474_y.field_151451_c;
        currentlyReduced = false;
    }

    @Override
    public void onDisable() {
        if (currentlyReduced) {
            restore();
        }
    }

    public void onFpsSample(int currentFps) {
        if (!isEnabled()) return;

        Setting threshold = getSetting("Min FPS Threshold");
        int minFps = threshold != null ? Math.round(threshold.getSlider()) : 30;

        if (currentFps < minFps && !currentlyReduced) {
            reduce();
        } else if (currentFps >= minFps + 10 && currentlyReduced) {
            restore();
        }
    }

    private void reduce() {
        prevParticleSetting = mc.field_71474_y.field_74362_aa;
        prevRenderDistance = mc.field_71474_y.field_151451_c;

        if (mc.field_71474_y.field_74362_aa < 1) mc.field_71474_y.field_74362_aa = 1;
        mc.field_71474_y.field_151451_c = Math.max(4, mc.field_71474_y.field_151451_c - 2);
        mc.field_71438_f.func_72712_a();
        currentlyReduced = true;
    }

    private void restore() {
        mc.field_71474_y.field_74362_aa = prevParticleSetting;
        mc.field_71474_y.field_151451_c = prevRenderDistance;
        mc.field_71438_f.func_72712_a();
        currentlyReduced = false;
    }

    public boolean isCurrentlyReduced() {
        return currentlyReduced;
    }
}
