package com.biggestbeauty.client.module.impl.render;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class CustomCrosshairModule extends Module {

    public CustomCrosshairModule(int keybind, boolean enabledByDefault) {
        super("Custom Crosshair", Category.RENDER, keybind, enabledByDefault);
    }

    public void render(ScaledResolution sr) {
        int cx = sr.func_78326_a() / 2;
        int cy = sr.func_78328_b() / 2;
        int color = RenderUtil.THEME_ACCENT;
        int len = 4;
        int gap = 2;
        int thickness = 1;

        RenderUtil.drawRect(cx - thickness / 2, cy - gap - len, cx + thickness, cy - gap, color);
        RenderUtil.drawRect(cx - thickness / 2, cy + gap, cx + thickness, cy + gap + len, color);
        RenderUtil.drawRect(cx - gap - len, cy - thickness / 2, cx - gap, cy + thickness, color);
        RenderUtil.drawRect(cx + gap, cy - thickness / 2, cx + gap + len, cy + thickness, color);
    }
}
