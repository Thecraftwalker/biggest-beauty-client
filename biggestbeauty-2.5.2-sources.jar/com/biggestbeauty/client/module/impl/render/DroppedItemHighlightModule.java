package com.biggestbeauty.client.module.impl.render;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;

public class DroppedItemHighlightModule extends Module {

    public DroppedItemHighlightModule(int keybind, boolean enabledByDefault) {
        super("Item Highlight", Category.RENDER, keybind, enabledByDefault);
    }
}
