package com.biggestbeauty.client.module.impl.render;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;

public class FullbrightModule extends Module {

    private float previousGamma;

    public FullbrightModule(int keybind, boolean enabledByDefault) {
        super("Fullbright", Category.RENDER, keybind, enabledByDefault);
        addSetting(Setting.slider("Gamma", 1000, 16, 1000, true));
    }

    @Override
    public void onEnable() {
        previousGamma = mc.field_71474_y.field_74333_Y;
        applyGamma();
    }

    @Override
    public void onDisable() {
        mc.field_71474_y.field_74333_Y = previousGamma;
    }

    public void applyGamma() {
        Setting gamma = getSetting("Gamma");
        mc.field_71474_y.field_74333_Y = gamma != null ? gamma.getSlider() : 1000F;
    }
}
