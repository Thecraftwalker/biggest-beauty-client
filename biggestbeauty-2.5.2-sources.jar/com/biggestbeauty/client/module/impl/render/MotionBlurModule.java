package com.biggestbeauty.client.module.impl.render;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;

/**
 * IMPORTANT — this is the most experimental rendering feature in the project.
 * Minecraft 1.8.9 has no built-in motion blur. This works by capturing each
 * fully-rendered frame into a persistent GL texture (glCopyTexImage2D), then
 * drawing that captured texture back over the next frame at low alpha before
 * capturing again — a "ghost frame" accumulation trick using only long-standing
 * 1.8.9 rendering APIs (Tessellator/WorldRenderer/GL11). Actual GL code lives
 * in RenderHandler. If it doesn't build or look right, that's the first place
 * to check — this is newer, less-proven territory than the rest of the project.
 */
public class MotionBlurModule extends Module {

    public MotionBlurModule(int keybind, boolean enabledByDefault) {
        super("Motion Blur", Category.RENDER, keybind, enabledByDefault);
        addSetting(Setting.slider("Strength", 35, 5, 80, true));
    }
}
