package com.biggestbeauty.client.module.impl.render;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;

public class NoFireModule extends Module {

    public NoFireModule(int keybind, boolean enabledByDefault) {
        super("No Fire Overlay", Category.RENDER, keybind, enabledByDefault);
    }
}
