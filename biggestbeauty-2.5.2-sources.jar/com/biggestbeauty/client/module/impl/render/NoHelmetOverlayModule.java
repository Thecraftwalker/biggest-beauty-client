package com.biggestbeauty.client.module.impl.render;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;

public class NoHelmetOverlayModule extends Module {

    public NoHelmetOverlayModule(int keybind, boolean enabledByDefault) {
        super("No Helmet Overlay", Category.RENDER, keybind, enabledByDefault);
    }
}
