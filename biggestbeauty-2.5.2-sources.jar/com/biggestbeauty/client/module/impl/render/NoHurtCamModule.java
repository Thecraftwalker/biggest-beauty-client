package com.biggestbeauty.client.module.impl.render;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;

public class NoHurtCamModule extends Module {

    public NoHurtCamModule(int keybind, boolean enabledByDefault) {
        super("No Hurt Cam", Category.RENDER, keybind, enabledByDefault);
    }
}
