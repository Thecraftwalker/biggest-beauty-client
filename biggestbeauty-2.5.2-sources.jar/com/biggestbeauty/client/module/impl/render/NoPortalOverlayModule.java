package com.biggestbeauty.client.module.impl.render;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;

public class NoPortalOverlayModule extends Module {

    public NoPortalOverlayModule(int keybind, boolean enabledByDefault) {
        super("No Portal Overlay", Category.RENDER, keybind, enabledByDefault);
    }
}
