package com.biggestbeauty.client.module.impl.render;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;

public class NoViewBobbingModule extends Module {

    private boolean previous;

    public NoViewBobbingModule(int keybind, boolean enabledByDefault) {
        super("No View Bobbing", Category.RENDER, keybind, enabledByDefault);
    }

    @Override
    public void onEnable() {
        previous = mc.field_71474_y.field_74336_f;
        mc.field_71474_y.field_74336_f = false;
    }

    @Override
    public void onDisable() {
        mc.field_71474_y.field_74336_f = previous;
    }
}
