package com.biggestbeauty.client.module.impl.render;

import com.biggestbeauty.client.module.Category;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;

public class ZoomModule extends Module {

    private boolean zooming = false;

    public ZoomModule(int keybind) {
        super("Zoom (hold)", Category.RENDER, keybind, false);
        addSetting(Setting.slider("Zoom Factor", 4, 2, 8, true));
    }

    public void setZooming(boolean zooming) {
        this.zooming = zooming;
    }

    public boolean isZooming() {
        return zooming;
    }

    public float apply(float currentFov) {
        if (!zooming) return currentFov;
        Setting factor = getSetting("Zoom Factor");
        float f = factor != null ? factor.getSlider() : 4F;
        return currentFov / f;
    }
}
