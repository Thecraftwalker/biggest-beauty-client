package com.biggestbeauty.client.util;

import com.biggestbeauty.client.BiggestBeautyClient;
import com.biggestbeauty.client.module.HudModule;
import com.biggestbeauty.client.module.Module;
import com.biggestbeauty.client.module.Setting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.LinkedHashMap;
import java.util.Map;

public class ClientConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public String clientName = "The Biggest Beauty Client";
    public Map<String, Boolean> moduleStates = new LinkedHashMap<>();
    public Map<String, Integer> keybinds = new LinkedHashMap<>();
    public Map<String, float[]> hudPositions = new LinkedHashMap<>();
    public Map<String, String> settingValues = new LinkedHashMap<>();

    private static File configDir() {
        File dir = new File(Minecraft.func_71410_x().field_71412_D, "config");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private static File mainFile() {
        return new File(configDir(), "biggestbeauty.json");
    }

    private static File profilesDir() {
        File dir = new File(configDir(), "biggestbeauty/profiles");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public void captureCurrentState() {
        moduleStates.clear();
        keybinds.clear();
        hudPositions.clear();
        settingValues.clear();
        for (Module m : BiggestBeautyClient.moduleManager.getModules()) {
            moduleStates.put(m.getName(), m.isEnabled());
            keybinds.put(m.getName(), m.getKeybind());
            if (m instanceof HudModule) {
                HudModule h = (HudModule) m;
                hudPositions.put(m.getName(), new float[]{h.getRelX(), h.getRelY()});
            }
            for (Setting s : m.getSettings()) {
                String key = m.getName() + "::" + s.getName();
                switch (s.getType()) {
                    case BOOLEAN:
                        settingValues.put(key, String.valueOf(s.getBool()));
                        break;
                    case SLIDER:
                        settingValues.put(key, String.valueOf(s.getSlider()));
                        break;
                    case TEXT:
                        settingValues.put(key, s.getText() != null ? s.getText() : "");
                        break;
                }
            }
        }
    }

    public void applyToModules() {
        for (Module m : BiggestBeautyClient.moduleManager.getModules()) {
            Boolean state = moduleStates.get(m.getName());

            Integer kb = keybinds.get(m.getName());
            if (kb != null) m.setKeybind(kb);

            if (m instanceof HudModule && hudPositions.containsKey(m.getName())) {
                float[] pos = hudPositions.get(m.getName());
                ((HudModule) m).setRelX(pos[0]);
                ((HudModule) m).setRelY(pos[1]);
            }

            for (Setting s : m.getSettings()) {
                String value = settingValues.get(m.getName() + "::" + s.getName());
                if (value == null) continue;
                try {
                    switch (s.getType()) {
                        case BOOLEAN:
                            s.setBool(Boolean.parseBoolean(value));
                            break;
                        case SLIDER:
                            s.setSlider(Float.parseFloat(value));
                            break;
                        case TEXT:
                            s.setText(value);
                            break;
                    }
                } catch (NumberFormatException ignored) {
                }
            }

            if (state != null) m.setEnabled(state);
        }
    }

    public void save() {
        captureCurrentState();
        try (FileWriter writer = new FileWriter(mainFile())) {
            GSON.toJson(this, writer);
        } catch (Exception e) {
            System.err.println("[BiggestBeauty] Failed to save config: " + e.getMessage());
        }
    }

    public static ClientConfig load() {
        File file = mainFile();
        if (!file.exists()) return new ClientConfig();
        try (FileReader reader = new FileReader(file)) {
            ClientConfig cfg = GSON.fromJson(reader, ClientConfig.class);
            return cfg != null ? cfg : new ClientConfig();
        } catch (Exception e) {
            System.err.println("[BiggestBeauty] Failed to load config: " + e.getMessage());
            return new ClientConfig();
        }
    }

    public void saveProfile(String name) {
        captureCurrentState();
        File file = new File(profilesDir(), sanitize(name) + ".json");
        try (FileWriter writer = new FileWriter(file)) {
            GSON.toJson(this, writer);
        } catch (Exception e) {
            System.err.println("[BiggestBeauty] Failed to save profile: " + e.getMessage());
        }
    }

    public static ClientConfig loadProfile(String name) {
        File file = new File(profilesDir(), sanitize(name) + ".json");
        if (!file.exists()) return null;
        try (FileReader reader = new FileReader(file)) {
            return GSON.fromJson(reader, ClientConfig.class);
        } catch (Exception e) {
            System.err.println("[BiggestBeauty] Failed to load profile: " + e.getMessage());
            return null;
        }
    }

    public static String[] listProfiles() {
        File[] files = profilesDir().listFiles((dir, name) -> name.endsWith(".json"));
        if (files == null) return new String[0];
        String[] names = new String[files.length];
        for (int i = 0; i < files.length; i++) {
            names[i] = files[i].getName().replace(".json", "");
        }
        return names;
    }

    private static String sanitize(String name) {
        return name.replaceAll("[^a-zA-Z0-9_\\-]", "_");
    }
}
