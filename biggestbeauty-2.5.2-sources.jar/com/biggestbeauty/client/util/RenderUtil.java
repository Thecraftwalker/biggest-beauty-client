package com.biggestbeauty.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;

public class RenderUtil {

    public static final int THEME_ACCENT = 0xFFF2A6D6;
    public static final int THEME_ACCENT_2 = 0xFFF7D774;
    public static final int THEME_BG = 0xB0141018;
    public static final int THEME_BG_HOVER = 0xC0221C2A;

    public static void drawStringRightAligned(String text, int rightX, int y, int color) {
        Minecraft mc = Minecraft.func_71410_x();
        int width = mc.field_71466_p.func_78256_a(text);
        drawShadowedString(text, rightX - width, y, color);
    }

    public static void drawShadowedString(String text, int x, int y, int color) {
        Minecraft mc = Minecraft.func_71410_x();
        mc.field_71466_p.func_175063_a(text, x, y, color);
    }

    public static void drawKeyBox(String label, int x, int y, int w, int h, boolean pressed) {
        Minecraft mc = Minecraft.func_71410_x();
        int bg = pressed ? THEME_ACCENT : THEME_BG;
        drawRect(x, y, x + w, y + h, bg);
        drawOutline(x, y, x + w, y + h, THEME_ACCENT_2, 1);

        int textWidth = mc.field_71466_p.func_78256_a(label);
        int textX = x + (w - textWidth) / 2;
        int textY = y + (h - 8) / 2;
        mc.field_71466_p.func_175063_a(label, textX, textY, pressed ? 0xFF1A1420 : 0xFFFFFFFF);
    }

    public static void drawRect(int left, int top, int right, int bottom, int color) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        Gui.func_73734_a(left, top, right, bottom, color);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void drawOutline(int left, int top, int right, int bottom, int color, int thickness) {
        drawRect(left, top, right, top + thickness, color);
        drawRect(left, bottom - thickness, right, bottom, color);
        drawRect(left, top, left + thickness, bottom, color);
        drawRect(right - thickness, top, right, bottom, color);
    }
}
