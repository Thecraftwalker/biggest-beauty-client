package com.biggestbeauty.client.util;

import java.util.ArrayDeque;
import java.util.Deque;

public class ToastQueue {

    public static class Toast {
        public final String message;
        public final long expiresAt;

        Toast(String message, long durationMs) {
            this.message = message;
            this.expiresAt = System.currentTimeMillis() + durationMs;
        }
    }

    private static final Deque<Toast> toasts = new ArrayDeque<>();
    private static final int MAX_VISIBLE = 4;

    public static void push(String message) {
        toasts.addLast(new Toast(message, 2500));
        while (toasts.size() > MAX_VISIBLE) toasts.pollFirst();
    }

    public static Deque<Toast> getActive() {
        long now = System.currentTimeMillis();
        toasts.removeIf(t -> t.expiresAt < now);
        return toasts;
    }
}
