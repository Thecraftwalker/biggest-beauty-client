package com.biggestbeauty.client.util.media;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.TargetDataLine;
import java.awt.AWTException;
import java.awt.Desktop;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * IMPORTANT — recording history, so you know what's proven vs experimental:
 *   v1: used a third-party video library (Monte Media) via JitPack — failed
 *       to resolve during a real build, every symbol was "cannot find symbol."
 *   v2: rewrote to capture PNG frames + a .wav using only JDK APIs
 *       (java.awt.Robot, javax.imageio, javax.sound.sampled) — this part
 *       compiled clean and has stayed the reliable core of the feature
 *       through every version since.
 *   v3: shelled out to a system-installed `ffmpeg` binary to encode frames
 *       into an .mp4. Worked in principle, but its real failure mode is that
 *       most people don't have ffmpeg installed, so encoding silently failed
 *       — exactly what got reported back.
 *   v4: switched to JCodec (pure-Java, Maven Central). The dependency itself
 *       resolved fine this time — but its actual API didn't match what was
 *       guessed (SequenceEncoder needs a 5-argument constructor with Format/
 *       Codec enum values, not the simple File constructor assumed, and has
 *       no encodeImage(BufferedImage) method). Confirmed by a real compile
 *       error, not speculation.
 *   v5 (this version): rather than risk a third wrong guess at JCodec's real
 *       API — or a fourth different library — this drops automatic mp4
 *       encoding entirely. You get PNG frames + audio.wav, guaranteed to
 *       compile and guaranteed to actually contain your recording, and a
 *       one-line ffmpeg command (printed to console when you stop recording,
 *       and in the README) if you want to combine them into a video
 *       yourself. Less convenient, but every part of it is something that
 *       has actually been confirmed working by a real build.
 */
public class GameRecorderUtil {

    private static Thread videoThread;
    private static Thread audioThread;
    private static AtomicBoolean running;
    private static File sessionDir;
    private static TargetDataLine micLine;
    private static AudioFormat audioFormat;
    private static ByteArrayOutputStream audioBuffer;
    private static int recordingFps;

    public static boolean isRecording() {
        return running != null && running.get();
    }

    public static void start(boolean includeAudio, int fps, File outputDir) throws IOException, AWTException, javax.sound.sampled.LineUnavailableException {
        if (isRecording()) return;

        if (!outputDir.exists()) outputDir.mkdirs();
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        sessionDir = new File(outputDir, "recording_" + stamp);
        sessionDir.mkdirs();
        recordingFps = fps;

        running = new AtomicBoolean(true);

        Rectangle bounds = getWindowBounds();
        Robot robot = new Robot();
        int frameDelayMs = Math.max(1, 1000 / Math.max(1, fps));

        videoThread = new Thread(() -> {
            int frameIndex = 0;
            while (running.get()) {
                try {
                    BufferedImage frame = robot.createScreenCapture(bounds);
                    File frameFile = new File(sessionDir, String.format("frame_%06d.png", frameIndex++));
                    ImageIO.write(frame, "png", frameFile);
                    Thread.sleep(frameDelayMs);
                } catch (Exception e) {
                    System.err.println("[BiggestBeauty] Frame capture error: " + e.getMessage());
                }
            }
        }, "BiggestBeauty-VideoCapture");
        videoThread.setDaemon(true);
        videoThread.start();

        if (includeAudio) {
            audioFormat = new AudioFormat(44100f, 16, 1, true, false);
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, audioFormat);
            if (!AudioSystem.isLineSupported(info)) {
                System.err.println("[BiggestBeauty] No microphone available for this format — recording video only.");
            } else {
                micLine = (TargetDataLine) AudioSystem.getLine(info);
                micLine.open(audioFormat);
                micLine.start();
                audioBuffer = new ByteArrayOutputStream();

                audioThread = new Thread(() -> {
                    byte[] buf = new byte[4096];
                    while (running.get()) {
                        int read = micLine.read(buf, 0, buf.length);
                        if (read > 0) audioBuffer.write(buf, 0, read);
                    }
                }, "BiggestBeauty-AudioCapture");
                audioThread.setDaemon(true);
                audioThread.start();
            }
        }
    }

    /**
     * Stops capture, writes out audio.wav if recorded, opens the folder, and
     * returns immediately — no encoding step, so this doesn't need a
     * background thread the way earlier versions with mp4 encoding did.
     */
    public static List<File> stop() throws IOException {
        if (running == null) return java.util.Collections.emptyList();
        running.set(false);

        try {
            if (videoThread != null) videoThread.join(2000);
        } catch (InterruptedException ignored) {}

        List<File> outputs = new ArrayList<>();
        File finishedSessionDir = sessionDir;
        if (finishedSessionDir != null) outputs.add(finishedSessionDir);

        if (micLine != null) {
            try {
                if (audioThread != null) audioThread.join(2000);
            } catch (InterruptedException ignored) {}
            micLine.stop();
            micLine.close();

            if (audioBuffer != null && audioBuffer.size() > 0) {
                byte[] audioBytes = audioBuffer.toByteArray();
                File wavFile = new File(finishedSessionDir, "audio.wav");
                try (AudioInputStream ais = new AudioInputStream(
                        new ByteArrayInputStream(audioBytes), audioFormat,
                        audioBytes.length / audioFormat.getFrameSize())) {
                    AudioSystem.write(ais, AudioFileFormat.Type.WAVE, wavFile);
                    outputs.add(wavFile);
                }
            }
            micLine = null;
            audioBuffer = null;
        }

        int fpsUsed = recordingFps;
        running = null;
        sessionDir = null;
        videoThread = null;
        audioThread = null;

        System.out.println("[BiggestBeauty] Recording saved to: " + finishedSessionDir.getAbsolutePath());
        System.out.println("[BiggestBeauty] To combine into an mp4 yourself (requires ffmpeg installed separately):");
        System.out.println("[BiggestBeauty]   ffmpeg -framerate " + fpsUsed
                + " -i frame_%06d.png -i audio.wav -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest output.mp4");

        revealInFileExplorer(finishedSessionDir);

        return outputs;
    }

    private static void revealInFileExplorer(File folder) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(folder);
            }
        } catch (Exception e) {
            System.err.println("[BiggestBeauty] Recording saved to " + folder.getAbsolutePath()
                    + " but couldn't auto-open it: " + e.getMessage());
        }
    }

    private static Rectangle getWindowBounds() {
        try {
            int x = org.lwjgl.opengl.Display.getX();
            int y = org.lwjgl.opengl.Display.getY();
            int w = org.lwjgl.opengl.Display.getWidth();
            int h = org.lwjgl.opengl.Display.getHeight();
            return new Rectangle(x, y, w, h);
        } catch (Exception e) {
            return java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment()
                    .getDefaultScreenDevice().getDefaultConfiguration().getBounds();
        }
    }
}
